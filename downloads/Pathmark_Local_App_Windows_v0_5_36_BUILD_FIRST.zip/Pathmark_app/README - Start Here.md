# Start Pathmark on Windows

Pathmark runs on your computer and opens in your browser.

## First setup

1. Extract the zip file.
2. Move the extracted `Pathmark_app` folder to the folder where you want to keep Pathmark.

   Recommended:

   ```text
   Documents\Pathmark\Pathmark_app
   ```

3. Open `Pathmark_app`.
4. Run `build_launcher_exe.bat` once.
5. This creates `Pathmark.exe`.
6. Open `Pathmark.exe` to start Pathmark.

If the executable cannot be built, use `Start Pathmark.cmd` as the fallback launcher.

## Where your files go

On first launch, Pathmark will ask where to keep your Pathmark system. For most users, this should be the parent folder that contains `Pathmark_app`.

Pathmark keeps your tasklists, backups, Google Calendar exports, Google Tasks exports, database, and planning files outside the replaceable app folder.

Recommended structure:

```text
Pathmark
├── 00_System
│   ├── pathmark.db
│   ├── Backups
│   ├── Tasklists
│   ├── Google Calendar Exports
│   └── Google Tasks Exports
├── 01_Body_And_Stability
├── 02_Home_And_Garden
└── Pathmark_app
    ├── Pathmark.exe
    ├── app
    ├── config
    └── requirements.txt
```

## Updating Pathmark

Before updating, open Pathmark and create an update backup.

Then replace only:

```text
Pathmark_app
```

Do not replace:

```text
00_System
Backups
Tasklists
Google Calendar Exports
Google Tasks Exports
area folders
```

The app folder is replaceable. Your Pathmark folder is not.

## Appearance

Pathmark includes the Seasonal theme, plus six high-contrast colour themes: Persimmon, Marigold, Moss, Lagoon, Iris, and Rosewood. You can change the theme during first-run setup or later in Settings.

## Pinning Pathmark

After building `Pathmark.exe`, open it once, then right-click the taskbar icon and choose **Pin to taskbar**.


## Launcher appearance

If Pathmark still opens with the old dark launcher, delete the old `Pathmark.exe` and run `build_launcher_exe.bat` again. The executable is built from the current launcher source, so an older compiled EXE will not update by itself.
