# Pathmark Windows app source

This folder contains the local Windows version of Pathmark.

## Build the launcher

Run:

```text
build_launcher_exe.bat
```

This creates:

```text
Pathmark.exe
```

Use `Start Pathmark.cmd` as the fallback if needed.

## Install location

Move the full `Pathmark_app` folder into the user's Pathmark folder, for example:

```text
Documents\Pathmark\Pathmark_app
```

Pathmark stores persistent data outside the app folder under `00_System`.


## Launcher appearance

If Pathmark still opens with the old dark launcher, delete the old `Pathmark.exe` and run `build_launcher_exe.bat` again. The executable is built from the current launcher source, so an older compiled EXE will not update by itself.
