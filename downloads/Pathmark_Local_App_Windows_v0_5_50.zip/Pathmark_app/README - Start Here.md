# Start Pathmark on Windows

Pathmark runs on your computer and opens in your browser.

## First setup

1. Extract the zip file.
2. Move the extracted `Pathmark_app` folder to a stable app location. Do not leave it in Downloads for day-to-day use.

   Recommended option:

   ```text
   Documents\Pathmark_app
   ```

3. Open `Pathmark_app`.
4. Run `build_launcher_exe.bat` once.
5. This creates `Pathmark.exe`.
6. Open `Pathmark.exe` to start Pathmark.
7. In the launcher, keep the default `Documents\Workspace` folder or change the workspace field before starting the app.

If the executable cannot be built, use `Start Pathmark.cmd` as the fallback launcher.

## What the Workspace folder means

The Workspace folder is the workspace for user projects. It is where Pathmark keeps area folders, exports, tasklists, backups, and the local database.

Pathmark defaults to creating and using:

```text
Documents\Workspace
```

Exports and backups default to:

```text
Documents\Workspace\00_System\Google Calendar Exports
Documents\Workspace\00_System\Google Tasks Exports
Documents\Workspace\00_System\Tasklists
Documents\Workspace\00_System\Backups
```

You can change this in the launcher before starting Pathmark, or later in **Settings → Setup and folders** using the workspace path field.

## Areas

Pathmark detects the existing top-level folders inside your selected Workspace folder and makes them available as Areas. Numbered folders such as `01_Body_And_Stability` are recommended because the number controls the order and makes the folder clearly identifiable as an Area. Existing ordinary folders can still be imported, but `00_System` is reserved and is not treated as an Area.

Continue keeping Pathmark project folders inside the selected Workspace folder so the app can detect them as Areas.

## Updating Pathmark

Before updating, open the launcher and choose:

```text
Update
```

Then replace only:

```text
Pathmark_app
```

Do not replace:

```text
Documents\Workspace
00_System
Backups
Tasklists
Google Calendar Exports
Google Tasks Exports
area folders
```

The app folder is replaceable. Your Pathmark workspace folder is not.

## Pinning Pathmark

After building `Pathmark.exe`, open it once, then right-click the taskbar icon and choose **Pin to taskbar**.
