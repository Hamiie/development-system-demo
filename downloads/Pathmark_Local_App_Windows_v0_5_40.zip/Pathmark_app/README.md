# Pathmark Windows app source

Pathmark is a local Windows Streamlit app for organising goals, routines, areas, exports, and review prompts.

This repository is currently Windows-only for the local launcher. Mac support has been removed for now so the Windows packaging and update workflow can stay simpler.

## Recommended local folder structure

For day-to-day use, keep the replaceable app folder inside the user's Pathmark folder:

```text
Documents\Pathmark\Pathmark_app
```

Persistent user data and exports are kept outside the replaceable app code folder:

```text
Documents\Pathmark
├── 00_System
│   ├── pathmark.db
│   ├── Backups
│   ├── Tasklists
│   ├── Google Calendar Exports
│   └── Google Tasks Exports
├── 01_Body_And_Stability
├── 02_Home_And_Garden
└── Pathmark_app
    ├── Pathmark.exe
    ├── DevelopmentSystemLauncher.py
    ├── app
    ├── assets
    ├── config
    └── requirements.txt
```

The app defaults to `Documents\Pathmark`. In Settings, the user can change the root and export folders, including using `Downloads\Pathmark` if they deliberately want exports there.

## Existing folders become Areas

Pathmark detects top-level folders in the selected Pathmark root and imports them as Areas. Numbered folders such as `01_Body_And_Stability` are supported, but numbering is not required.

The import is read-only. It does not delete, rename, move, or empty the user's folders.

Ignored folders include `00_System`, `Pathmark_app`, `Backups`, `Tasklists`, `Google Calendar Exports`, and `Google Tasks Exports`.

## Run locally without building the executable

Open a Command Prompt in this folder and run:

```text
run_app.bat
```

This starts Streamlit on port `8545` in headless mode so the launcher or browser controls when the app window opens.

## Build the Windows launcher

Run:

```text
build_launcher_exe.bat
```

This creates:

```text
Pathmark.exe
```

Use `Start Pathmark.cmd` as the fallback if the executable has not been built yet.

## Launcher behaviour

The launcher now:

- uses the same Pathmark branding as the app
- starts Streamlit in headless mode
- reuses the existing app on port `8545` rather than opening a second local app window
- includes `Backup local data`
- includes `Backup and check updates`

## Updating Pathmark

Before replacing the app folder, use the launcher action:

```text
Backup and check updates
```

Then replace only the app files/folder. Do not replace the user's `00_System`, export folders, backups, or Area folders.

## GitHub upload note

For a GitHub repository, upload the contents of this folder as the repository root.

Do not upload local-only files such as `.venv`, `__pycache__`, `Pathmark.exe`, `00_System`, `data`, `output`, or generated exports.
