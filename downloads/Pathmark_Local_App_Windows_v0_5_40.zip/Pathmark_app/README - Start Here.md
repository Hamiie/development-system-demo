# Start Pathmark on Windows

Pathmark runs on your computer and opens in your browser.

## First setup

1. Extract the zip file.
2. Move the extracted `Pathmark_app` folder to the folder where you want to keep Pathmark.

   Recommended:

   ```text
   Documents\Pathmark\Pathmark_app
   ```

3. Open `Pathmark_app`.
4. Run `build_launcher_exe.bat` once.
5. This creates `Pathmark.exe`.
6. Open `Pathmark.exe` to start Pathmark.

If the executable cannot be built, use `Start Pathmark.cmd` as the fallback launcher.

## Where your files go

Pathmark defaults to:

```text
Documents\Pathmark
```

Exports and backups default to:

```text
Documents\Pathmark\00_System\Google Calendar Exports
Documents\Pathmark\00_System\Google Tasks Exports
Documents\Pathmark\00_System\Tasklists
Documents\Pathmark\00_System\Backups
```

You can change this in **Settings → Setup and folders**. There are quick buttons for `Documents\Pathmark` and `Downloads\Pathmark`, and text boxes for custom folder paths.

## Areas

Pathmark detects the existing top-level folders inside your selected Pathmark folder and makes them available as Areas. These do not need to have fixed names. Numbered folders such as `01_Body_And_Stability` are supported, but ordinary folders are also imported.

## Updating Pathmark

Before updating, open the launcher and choose:

```text
Backup and check updates
```

Then replace only:

```text
Pathmark_app
```

Do not replace:

```text
00_System
Backups
Tasklists
Google Calendar Exports
Google Tasks Exports
area folders
```

The app folder is replaceable. Your Pathmark folder is not.

## Pinning Pathmark

After building `Pathmark.exe`, open it once, then right-click the taskbar icon and choose **Pin to taskbar**.
