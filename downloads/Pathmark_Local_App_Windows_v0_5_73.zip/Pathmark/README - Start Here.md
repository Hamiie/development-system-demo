# Start Pathmark on Windows

Pathmark runs on your computer and opens in your browser.

## First setup

1. Extract the zip file.
2. Move the extracted `Pathmark` folder to a stable app location. Do not leave it in Downloads for day-to-day use.

   Recommended option:

   ```text
   Documents\Pathmark
   ```

3. Open `Pathmark`.
4. Run `build_launcher_exe.bat` once.
5. This creates `Pathmark.exe`.
6. Open `Pathmark.exe` to start Pathmark.
7. In the launcher, keep the default `Documents\Workspace` folder or change the workspace field before starting the app.

If the executable cannot be built, use `Start Pathmark.cmd` as the fallback launcher.

## What the Workspace folder means

The Workspace folder is the workspace for user projects. It is where Pathmark keeps area folders, exports, tasklists, backups, and the local database.

Pathmark defaults to creating and using:

```text
Documents\Workspace
```

Exports and backups default to:

```text
Documents\Workspace\00_System\Google Calendar Exports
Documents\Workspace\00_System\Google Tasks Exports
Documents\Workspace\00_System\Tasklists
Documents\Workspace\00_System\Backups
```

You can change this in the launcher before starting Pathmark, or later in **Settings → Setup and folders** using the workspace path field.

## Areas

Pathmark only treats numbered top-level folders inside your selected Workspace folder as Areas. Use names such as `01_Body_And_Stability`, `02_Home_And_Garden`, and `03_Making_And_Craft`. The number controls the order and prevents ordinary folders from being imported by mistake. `00_System` is reserved and is not treated as an Area.

Continue keeping Pathmark project folders inside the selected Workspace folder so the app can detect them as Areas.

## Updating Pathmark

Before updating, open the launcher and choose:

```text
Update
```

Then replace only:

```text
Pathmark
```

Do not replace:

```text
Documents\Workspace
00_System
Backups
Tasklists
Google Calendar Exports
Google Tasks Exports
area folders
```

The app folder is replaceable. Your Pathmark workspace folder is not.

## Pinning Pathmark

After building `Pathmark.exe`, open it once, then right-click the taskbar icon and choose **Pin to taskbar**.


## v0.5.72

This release simplifies setup and workflow: the launcher focuses on the Workspace and update checks, the app handles themes, the sidebar follows the main workflow, Areas hide folder/Markdown internals, and goals/routines quietly maintain their Workspace files when saved.


## v0.5.72

This release adds optional user-authorised Google Sheets OAuth for on-the-go capture and desktop sync. CSV import/export remains available as the simplest workflow. The desktop OAuth token is stored in the Workspace system folder, not in the replaceable app folder.


## On-the-go Google Sheets sync

Pathmark uses user-authorised OAuth for Google Sheets sync. The hosted app and desktop app request the narrower Google `drive.file` permission so they can work with the Pathmark sync sheet used by the app, rather than asking for access to every spreadsheet in the user's Google account. CSV import remains available as the safest fallback.


## v0.5.73

Hosted release hub update: Supabase access management now prefers Secret API keys (`sb_secret_...`) instead of legacy service-role keys. The local desktop app is otherwise unchanged from v0.5.72.
