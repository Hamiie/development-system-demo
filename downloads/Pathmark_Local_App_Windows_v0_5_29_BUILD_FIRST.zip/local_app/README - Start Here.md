# Start Pathmark on Windows

Pathmark runs on your computer and opens in your browser. This lets it create your Pathmark folder, tasklists, backups, Google Calendar exports, and Google Tasks exports on your own computer.

## Step 1: Build the launcher

Double-click:

```text
build_launcher_exe.bat
```

This creates:

```text
Start Pathmark.exe
```

This step may take a few minutes the first time.

## Step 2: Start Pathmark

Double-click:

```text
Start Pathmark.exe
```

Pathmark will open in your browser.

## Fallback option

If the executable cannot be built or does not start, double-click:

```text
Start Pathmark.cmd
```

## Safety

Pathmark should create missing folders and files only. It should not delete your files or replace your Pathmark folder during updates.
