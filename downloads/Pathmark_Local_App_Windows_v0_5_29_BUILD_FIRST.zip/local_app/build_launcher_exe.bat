@echo off
setlocal
cd /d "%~dp0"
title Build Pathmark Launcher

echo Building the friendly launcher executable...
echo.

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -m pip install --upgrade pip pyinstaller
  py -m PyInstaller --onefile --noconsole --name "Start Pathmark" DevelopmentSystemLauncher.py
  goto done
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python -m pip install --upgrade pip pyinstaller
  python -m PyInstaller --onefile --noconsole --name "Start Pathmark" DevelopmentSystemLauncher.py
  goto done
)

echo Python was not found. Please install Python 3.11 or later and try again.
pause
exit /b 1

:done
if exist "dist\Start Pathmark.exe" (
  copy /Y "dist\Start Pathmark.exe" "Start Pathmark.exe" >nul
  echo.
  echo Built Start Pathmark.exe in this folder.
) else (
  echo Build finished but the expected exe was not found.
)
pause
