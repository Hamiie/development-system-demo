from __future__ import annotations

import os
import queue
import shutil
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText

APP_NAME = "Development System"
DEFAULT_PORT = 8544


def app_root() -> Path:
    # When bundled with PyInstaller, sys.executable is the launcher exe.
    # The packaged app should place the exe in the same folder as app/, config/, requirements.txt.
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


ROOT = app_root()
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("760x520")
        self.minsize(680, 440)
        self.configure(bg="#241D17")
        self.proc: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.header = tk.Label(
            self,
            text="Development System",
            font=("Segoe UI", 18, "bold"),
            fg="#F5EDE2",
            bg="#241D17",
            anchor="w",
        )
        self.header.pack(fill="x", padx=22, pady=(18, 4))

        self.sub = tk.Label(
            self,
            text="Local app launcher — starts Streamlit on this computer so folders, Markdown, backups, and exports work locally.",
            font=("Segoe UI", 10),
            fg="#D8C7B3",
            bg="#241D17",
            anchor="w",
            wraplength=700,
            justify="left",
        )
        self.sub.pack(fill="x", padx=22, pady=(0, 14))

        btn_frame = tk.Frame(self, bg="#241D17")
        btn_frame.pack(fill="x", padx=22, pady=(0, 12))

        self.start_btn = tk.Button(
            btn_frame,
            text="Start Development System",
            command=self.start,
            bg="#B9855A",
            fg="#1E1813",
            activebackground="#C9976A",
            activeforeground="#1E1813",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        )
        self.start_btn.pack(side="left")

        self.stop_btn = tk.Button(
            btn_frame,
            text="Stop app",
            command=self.stop_app,
            state="disabled",
            bg="#4B3D30",
            fg="#F5EDE2",
            activebackground="#5C4A3A",
            activeforeground="#F5EDE2",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10),
        )
        self.stop_btn.pack(side="left", padx=(10, 0))

        self.open_btn = tk.Button(
            btn_frame,
            text="Open in browser",
            command=lambda: webbrowser.open(self.current_url()),
            state="disabled",
            bg="#4B3D30",
            fg="#F5EDE2",
            activebackground="#5C4A3A",
            activeforeground="#F5EDE2",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10),
        )
        self.open_btn.pack(side="left", padx=(10, 0))

        self.log = ScrolledText(
            self,
            height=18,
            bg="#1E1813",
            fg="#F5EDE2",
            insertbackground="#F5EDE2",
            font=("Consolas", 9),
            relief="flat",
            padx=10,
            pady=10,
        )
        self.log.pack(fill="both", expand=True, padx=22, pady=(0, 18))
        self.port = DEFAULT_PORT
        self.after(150, self.drain_log)
        self.write("Ready. Click Start Development System.\n")
        self.write(f"App folder: {ROOT}\n")

    def current_url(self) -> str:
        return f"http://localhost:{self.port}"

    def write(self, text: str) -> None:
        self.log.insert("end", text)
        self.log.see("end")

    def enqueue(self, text: str) -> None:
        self.log_queue.put(text)

    def drain_log(self) -> None:
        while not self.log_queue.empty():
            self.write(self.log_queue.get_nowait())
        self.after(150, self.drain_log)

    def find_python_cmd(self) -> list[str] | None:
        # Prefer the Windows py launcher if available.
        for cmd in (["py", "-3"], ["python"]):
            try:
                subprocess.run(cmd + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
                return cmd
            except Exception:
                continue
        return None

    def free_port(self, start: int = DEFAULT_PORT) -> int:
        for port in range(start, start + 50):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                try:
                    s.bind(("127.0.0.1", port))
                    return port
                except OSError:
                    continue
        return start

    def run_and_log(self, cmd: list[str], cwd: Path | None = None) -> int:
        self.enqueue("\n> " + " ".join(map(str, cmd)) + "\n")
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd or ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            self.enqueue(line)
        return proc.wait()

    def ensure_environment(self) -> bool:
        if not APP_FILE.exists():
            messagebox.showerror(APP_NAME, f"Cannot find app/main.py in:\n{ROOT}")
            return False
        if not REQUIREMENTS.exists():
            messagebox.showerror(APP_NAME, f"Cannot find requirements.txt in:\n{ROOT}")
            return False

        pycmd = self.find_python_cmd()
        if pycmd is None:
            messagebox.showerror(
                APP_NAME,
                "Python 3 is not installed or could not be found.\n\n"
                "Install Python 3.11 or later from python.org, then run this launcher again.",
            )
            webbrowser.open("https://www.python.org/downloads/")
            return False

        if not VENV_PYTHON.exists():
            self.enqueue("Creating local Python environment...\n")
            code = self.run_and_log(pycmd + ["-m", "venv", str(VENV)], cwd=ROOT)
            if code != 0:
                messagebox.showerror(APP_NAME, "Could not create the local Python environment. See the log for details.")
                return False

        self.enqueue("Installing/checking required packages...\n")
        code = self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], cwd=ROOT)
        if code != 0:
            messagebox.showerror(APP_NAME, "Could not install required packages. See the log for details.")
            return False
        return True

    def start(self) -> None:
        self.start_btn.config(state="disabled")
        threading.Thread(target=self.start_worker, daemon=True).start()

    def start_worker(self) -> None:
        try:
            if not self.ensure_environment():
                self.start_btn.config(state="normal")
                return
            self.port = self.free_port(DEFAULT_PORT)
            cmd = [
                str(VENV_PYTHON),
                "-m",
                "streamlit",
                "run",
                str(APP_FILE),
                "--server.port",
                str(self.port),
                "--server.headless",
                "true",
                "--browser.gatherUsageStats",
                "false",
            ]
            self.enqueue(f"\nStarting app at {self.current_url()}...\n")
            self.proc = subprocess.Popen(
                cmd,
                cwd=str(ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            self.stop_btn.config(state="normal")
            self.open_btn.config(state="normal")
            time.sleep(3)
            webbrowser.open(self.current_url())
            assert self.proc.stdout is not None
            for line in self.proc.stdout:
                self.enqueue(line)
            code = self.proc.wait()
            self.enqueue(f"\nApp stopped with exit code {code}.\n")
        except Exception as exc:
            self.enqueue(f"\nError: {exc}\n")
            messagebox.showerror(APP_NAME, str(exc))
        finally:
            self.proc = None
            self.start_btn.config(state="normal")
            self.stop_btn.config(state="disabled")
            self.open_btn.config(state="disabled")

    def stop_app(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.enqueue("Stopping app...\n")
            self.proc.terminate()

    def on_close(self) -> None:
        self.stop_app()
        self.destroy()


if __name__ == "__main__":
    Launcher().mainloop()
