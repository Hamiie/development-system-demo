@echo off
setlocal
cd /d "%~dp0"
title Build Development System Launcher

echo Building Start Development System.exe...
echo.

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -m pip install --upgrade pip pyinstaller
  py -m PyInstaller --onefile --noconsole --name "Start Development System" DevelopmentSystemLauncher.py
  goto done
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python -m pip install --upgrade pip pyinstaller
  python -m PyInstaller --onefile --noconsole --name "Start Development System" DevelopmentSystemLauncher.py
  goto done
)

echo Python was not found. Please install Python 3.11 or later and try again.
pause
exit /b 1

:done
if exist "dist\Start Development System.exe" (
  copy /Y "dist\Start Development System.exe" "Start Development System.exe" >nul
  echo.
  echo Built Start Development System.exe in this folder.
) else (
  echo Build finished but the expected exe was not found.
)
pause
