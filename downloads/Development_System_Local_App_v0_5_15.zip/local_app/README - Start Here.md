# Development System Local App

This is the local version of Development System. It runs with Streamlit, but it runs on your own computer and opens in your browser.

Because it runs locally, it can create and update your own Development folder, Markdown files, backups, Google Calendar exports, and Google Tasks exports.

## Start the app

Double-click:

```text
Start Development System.cmd
```

If `Start Development System.exe` is present, the `.cmd` file will use it. If not, it will run the Python launcher directly.

On first run, the launcher may create a local Python environment and install requirements. Then the app will open in your browser at a local address such as:

```text
http://localhost:8544
```

## First setup

The app will ask where your Development system should live. It will suggest a folder such as:

```text
C:\Users\<you>\OneDrive\Documents\Development
```

You can choose a different folder.

The app may create missing folders and Markdown files. It must not delete existing files or empty existing folders. Markdown files are backed up before being updated.

## Exports

Google Calendar `.ics` files are written to:

```text
Development\CalendarExports
```

Google Tasks `.csv` files are written to:

```text
Development\GoogleTasksExports
```

Backups are written under:

```text
Development\00_System\Backups
```

## Updates

Use the Streamlit Cloud landing page where you downloaded this package to check for newer versions.

Before updating, create a backup from Settings in the local app.
