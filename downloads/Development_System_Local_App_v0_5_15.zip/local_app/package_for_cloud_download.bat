@echo off
setlocal
cd /d "%~dp0"
title Package Development System Local App

set OUT=Development_System_Local_App_v0_5_15.zip
if exist "%OUT%" del "%OUT%"

powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'app','config','docs','requirements.txt','Start Development System.cmd','DevelopmentSystemLauncher.py','README - Start Here.md' -DestinationPath '%OUT%' -Force"

echo Created %OUT%
pause
