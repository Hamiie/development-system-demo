# Development System App v0.5.12

This version is configured for the real Development folder rather than the earlier sandbox.

Default folders:

```text
C:\Users\Hamis\OneDrive\Documents\Development
C:\Users\Hamis\OneDrive\Documents\Development\00_System
C:\Users\Hamis\OneDrive\Documents\Development\CalendarExports
C:\Users\Hamis\OneDrive\Documents\Development\GoogleTasksExports
```

Safety rules:

- The app creates missing folders only.
- It does not delete, empty, replace, or overwrite existing non-Markdown files.
- Markdown regeneration backs up existing Markdown files before writing.
- Calendar exports are written to `CalendarExports`.
- Google Tasks exports are written to `GoogleTasksExports`.

Run with:

```bat
run_app.bat
```

Manual run:

```bat
py -m pip install -r requirements.txt
py -m streamlit run app\main.py --server.port 8541
```


## v0.5.2 note

This package removes remaining sandbox-facing wording from the app UI. It is intended to work from `C:\Users\Hamis\OneDrive\Documents\Development` and only creates missing folders/files. It does not delete existing files or empty non-empty folders. Markdown files may be updated, with backups created first.


## v0.5.6 note

New areas now recognise existing numbered area folders under the Development root and suggest the next number in sequence, for example `07_New_Area`. Existing files and non-empty folders are not deleted, emptied, or renamed.


## v0.5.6

- Fixes the sample ICS diagnostic KeyError when sample rows do not include an `id`.
- Updates the launcher so the console closes normally when the Streamlit app is stopped, but still pauses if an error occurs.


## v0.5.6

- Restores the Home page title after an area-name collision.
- Splits Home and Tasklist actions into Goal actions and Routine tasks.
- Shows routine-linked tasks inside the selected Routine, so imported routine tasks are visible at their source.
- Keeps Areas as top-level Development folders and Specific area as the smaller category within the area.


## v0.5.8

Settings has been reorganised into tabs: Setup and folders, Appearance, Maintenance, and Compatibility and logs. Button rows are now grouped by purpose rather than scattered across the page.


## v0.5.12

- Changes routines from once-off task completion to recurring activities.
- Routine activities inherit the parent routine repeat pattern.
- Each routine activity can have its own start time, end time, location, tasklist inclusion, Google Calendar export, and Google Tasks starting prompt.
- Routine activities use Included/Paused rather than Done.
- Google Calendar export creates one recurring event per included routine activity.
- Google Tasks export creates prompt rows for the next routine activity occurrences, linked back to the related calendar item.


## v0.5.15 Google Tasks repeat behaviour

Repeating routines now prepare one next Google Tasks prompt by default. Google Calendar exports recurring time blocks through ICS RRULEs, but the Google Tasks CSV importer creates one task per row. To avoid flooding Google Tasks with many future prompts, use the optional Routine prompt rows selector on the Google Tasks Export page only when you intentionally want more future prompt rows.
