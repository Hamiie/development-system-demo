@echo off
setlocal
cd /d "%~dp0"
title Development System

if exist "Start Development System.exe" (
  "Start Development System.exe"
  exit /b %ERRORLEVEL%
)

echo Welcome to Development System.
echo.
echo Starting the local app. This may install required Python packages on first run.
echo.

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py DevelopmentSystemLauncher.py
  exit /b %ERRORLEVEL%
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python DevelopmentSystemLauncher.py
  exit /b %ERRORLEVEL%
)

echo Python was not found on this computer.
echo Please install Python 3.11 or later from https://www.python.org/downloads/
echo Then run this file again.
pause
