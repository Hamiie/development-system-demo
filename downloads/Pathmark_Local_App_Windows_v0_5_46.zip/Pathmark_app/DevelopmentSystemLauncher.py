from __future__ import annotations

import json
import os
import queue
import socket
import subprocess
import sys
import threading
import time
import zipfile
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk

APP_NAME = "Pathmark"
APP_VERSION = "Local App v0.5.46"
WINDOWS_ONLY = True
DEFAULT_PORT = 8545
THEME_PRESETS = ["Default", "Seasonal", "Persimmon", "Marigold", "Moss", "Lagoon", "Iris", "Rosewood", "Custom"]
THEME_MODES = ["Light", "Dark"]
RELEASE_HUB_URL = "https://pathmark.streamlit.app/"


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def documents_base() -> Path:
    candidates: list[Path] = []
    for key in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        value = os.environ.get(key)
        if value:
            candidates.append(Path(value) / "Documents")
    candidates.append(Path.home() / "OneDrive" / "Documents")
    candidates.append(Path.home() / "Documents")
    for candidate in candidates:
        try:
            if candidate.exists():
                return candidate
        except Exception:
            pass
    return Path.home() / "Documents"


def default_workspace_root() -> Path:
    return documents_base() / "Workspace"


def likely_workspace_root() -> Path:
    root = app_root()
    try:
        if root.name.lower() in ("pathmark_app", "local_app") and root.parent.name.lower() in ("workspace", "pathmark"):
            return root.parent
    except Exception:
        pass
    return default_workspace_root()


ROOT = app_root()
LAUNCHER_CONFIG = ROOT / "config" / "launcher_settings.json"
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"
ICON = ROOT / "assets" / "pathmark.ico"
ICON_PNG = ROOT / "assets" / "pathmark.png"
CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def load_launcher_config() -> dict:
    try:
        if LAUNCHER_CONFIG.exists():
            return json.loads(LAUNCHER_CONFIG.read_text(encoding="utf-8")) or {}
    except Exception:
        pass
    return {}


def load_configured_user_root() -> Path:
    data = load_launcher_config()
    value = data.get("workspace_root") or data.get("pathmark_root")
    if value:
        return Path(value).expanduser()
    return likely_workspace_root()


def normalise_preset(value: str | None) -> str:
    value = (value or "Default").strip()
    if value == "Pathmark":
        value = "Default"
    return value if value in THEME_PRESETS else "Default"


def load_configured_theme() -> tuple[str, str]:
    data = load_launcher_config()
    preset = normalise_preset(data.get("theme_preset"))
    mode = data.get("theme_mode") or "Light"
    if mode not in THEME_MODES:
        mode = "Light"
    return preset, mode


def save_launcher_config(path: Path | None = None, theme_preset: str | None = None, theme_mode: str | None = None) -> None:
    data = load_launcher_config()
    if path is not None:
        data["workspace_root"] = str(path)
        data["pathmark_root"] = str(path)
    if theme_preset is not None:
        data["theme_preset"] = normalise_preset(theme_preset)
    if theme_mode is not None:
        data["theme_mode"] = theme_mode if theme_mode in THEME_MODES else "Light"
    LAUNCHER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    LAUNCHER_CONFIG.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        if path is not None:
            system = Path(path).expanduser() / "00_System"
            system.mkdir(parents=True, exist_ok=True)
            (system / "pathmark_launcher_settings.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


def set_user_root(path: Path) -> None:
    global USER_ROOT, USER_SYSTEM, USER_DB, USER_BACKUPS
    USER_ROOT = path.expanduser()
    USER_SYSTEM = USER_ROOT / "00_System"
    USER_DB = USER_SYSTEM / "pathmark.db"
    USER_BACKUPS = USER_SYSTEM / "Backups" / "Updates"


def ensure_user_workspace() -> None:
    USER_ROOT.mkdir(parents=True, exist_ok=True)
    for folder in (USER_SYSTEM, USER_SYSTEM / "Google Calendar Exports", USER_SYSTEM / "Google Tasks Exports", USER_SYSTEM / "Tasklists", USER_SYSTEM / "Backups"):
        folder.mkdir(parents=True, exist_ok=True)
    readme = USER_ROOT / "README - Pathmark workspace.md"
    if not readme.exists():
        readme.write_text("""# Pathmark workspace

This is the workspace folder Pathmark uses for projects, area folders, exports, tasklists, backups, and the local database.

Keep this workspace when updating Pathmark. Replace only the separate `Pathmark_app` folder in your app location.

## Area folder naming

Pathmark works best when area folders are numbered, for example:

```text
01_Body_And_Stability
02_Home_And_Garden
03_Making_And_Craft
```

The number controls display order and helps Pathmark recognise a top-level folder as an Area.

`00_System` is reserved for Pathmark's database, exports, backups, and system files.

When you add a new Area in the app, Pathmark suggests the next number automatically.
""", encoding="utf-8")


USER_ROOT = load_configured_user_root()
USER_SYSTEM = USER_ROOT / "00_System"
USER_DB = USER_SYSTEM / "pathmark.db"
USER_BACKUPS = USER_SYSTEM / "Backups" / "Updates"


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1040x780")
        self.minsize(780, 620)
        self.proc: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.logs: list[str] = []
        self.port = DEFAULT_PORT
        self.started = False
        self.theme_preset, self.theme_mode = load_configured_theme()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        if ICON.exists():
            try:
                self.iconbitmap(default=str(ICON))
            except Exception:
                try:
                    self.iconbitmap(str(ICON))
                except Exception:
                    pass
        self.palette = {
            "bg": "#F7F6F2", "hero": "#FBFAF7", "surface": "#FFFFFF", "surface2": "#EFEEE8",
            "text": "#151917", "muted": "#626966", "soft": "#818783", "accent": "#334E68",
            "accent_hover": "#253E54", "accent_soft": "#E7EEF4", "warm": "#A66A43", "line": "#D8D4CB",
            "success": "#E8F4EA", "success_text": "#255833"
        }
        self.configure(bg=self.palette["bg"])
        self._style()
        self._build_scrollable_ui()
        self.after(150, self.drain_log)
        self.after(250, lambda: self.set_status("Ready to open Pathmark", "Confirm the workspace and theme, then choose Open Pathmark. The default workspace is Documents\\Workspace.", 8, 0))

    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Pathmark.Horizontal.TProgressbar", troughcolor=self.palette["surface2"], background=self.palette["warm"], bordercolor=self.palette["surface2"], lightcolor=self.palette["warm"], darkcolor=self.palette["warm"], thickness=10)
        style.configure("Pathmark.TCombobox", fieldbackground="#FFFFFF", background="#FFFFFF", foreground=self.palette["text"], arrowcolor=self.palette["accent"])

    def _button(self, parent, text, command, *, primary=False, disabled=False):
        btn = tk.Button(
            parent, text=text, command=command, state="disabled" if disabled else "normal",
            bg=self.palette["accent"] if primary else self.palette["surface2"],
            fg="#FFFFFF" if primary else self.palette["text"],
            activebackground=self.palette["accent_hover"] if primary else "#E4E1D9",
            activeforeground="#FFFFFF" if primary else self.palette["text"],
            disabledforeground="#8A8F8B", relief="flat", bd=0, padx=18, pady=12,
            font=("Segoe UI", 10, "bold" if primary else "normal"), cursor="hand2"
        )
        return btn

    def _logo(self, parent, size=46):
        holder = tk.Frame(parent, bg=self.palette["hero"], width=size, height=size)
        holder.pack_propagate(False)
        self.logo_image = None
        if ICON_PNG.exists():
            try:
                raw = tk.PhotoImage(file=str(ICON_PNG))
                factor = max(1, min(raw.width() // size, raw.height() // size))
                self.logo_image = raw.subsample(factor, factor)
                tk.Label(holder, image=self.logo_image, bg=self.palette["hero"]).pack(expand=True)
                return holder
            except Exception:
                pass
        c = tk.Canvas(holder, width=size, height=size, bg=self.palette["hero"], highlightthickness=0)
        c.create_rectangle(3, 3, size - 3, size - 3, fill="#182A27", outline="")
        c.create_line(size*.26, size*.68, size*.43, size*.50, size*.58, size*.57, size*.74, size*.34, fill="#F6F4EF", width=max(3, size//10), smooth=True)
        c.pack(expand=True)
        return holder

    def _build_scrollable_ui(self) -> None:
        self.canvas = tk.Canvas(self, bg=self.palette["bg"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.content = tk.Frame(self.canvas, bg=self.palette["bg"])
        self.window_id = self.canvas.create_window((0, 0), window=self.content, anchor="nw")
        self.content.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfig(self.window_id, width=e.width))
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self._build_ui(self.content)

    def _on_mousewheel(self, event) -> None:
        try:
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    def _section_card(self, parent, title: str, body: str):
        card = tk.Frame(parent, bg=self.palette["surface"], highlightbackground=self.palette["line"], highlightthickness=1)
        tk.Label(card, text=title, bg=self.palette["surface"], fg=self.palette["text"], font=("Segoe UI", 16, "bold"), anchor="w").pack(fill="x", padx=24, pady=(22, 4))
        tk.Label(card, text=body, bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 10), anchor="w", wraplength=860, justify="left").pack(fill="x", padx=24, pady=(0, 18))
        return card

    def _build_ui(self, outer) -> None:
        hero = tk.Frame(outer, bg=self.palette["hero"])
        hero.pack(fill="x")
        inner = tk.Frame(hero, bg=self.palette["hero"])
        inner.pack(fill="x", padx=48, pady=(28, 30))
        self._logo(inner, 46).pack(anchor="w", pady=(0, 22))
        tk.Label(inner, text="Local app launcher", bg=self.palette["accent_soft"], fg=self.palette["accent"], padx=12, pady=6, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 12))
        tk.Label(inner, text="Pathmark", font=("Segoe UI Variable Display", 52, "bold"), fg=self.palette["text"], bg=self.palette["hero"], anchor="w").pack(fill="x")
        tk.Label(inner, text="Make time for routines. Reduce friction with prompts. Keep goals moving.", font=("Segoe UI", 11, "bold"), fg=self.palette["text"], bg=self.palette["hero"], anchor="w").pack(fill="x", pady=(8, 0))

        body = tk.Frame(outer, bg=self.palette["bg"])
        body.pack(fill="both", expand=True, padx=42, pady=(22, 30))

        intro = tk.Frame(body, bg=self.palette["success"], highlightbackground="#C7E3CC", highlightthickness=1)
        intro.pack(fill="x", pady=(0, 16))
        tk.Label(intro, text="Choose your workspace before opening the app", bg=self.palette["success"], fg=self.palette["success_text"], font=("Segoe UI", 13, "bold"), anchor="w").pack(fill="x", padx=22, pady=(16, 4))
        tk.Label(intro, text="Pathmark stores your projects, numbered Area folders, exports, tasklists, backups, and local database in the workspace. The default is Documents\\Workspace, but you can point this to an existing folder before launching.", bg=self.palette["success"], fg=self.palette["success_text"], font=("Segoe UI", 10), anchor="w", wraplength=900, justify="left").pack(fill="x", padx=22, pady=(0, 16))

        workspace_card = self._section_card(body, "1. Workspace", "Use the default workspace or choose your existing project folder. Pathmark will create system folders inside the selected workspace only after you open or save it.")
        workspace_card.pack(fill="x", pady=(0, 16))
        form = tk.Frame(workspace_card, bg=self.palette["surface"])
        form.pack(fill="x", padx=24, pady=(0, 22))
        form.grid_columnconfigure(1, weight=1)
        tk.Label(form, text="Workspace folder", bg=self.palette["surface"], fg=self.palette["text"], font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 12), pady=6)
        self.workspace_var = tk.StringVar(value=str(USER_ROOT))
        self.workspace_entry = tk.Entry(form, textvariable=self.workspace_var, bg="#FFFFFF", fg=self.palette["text"], relief="solid", bd=1, font=("Segoe UI", 10))
        self.workspace_entry.grid(row=0, column=1, sticky="ew", pady=6, ipady=8)
        self._button(form, "Browse", self.choose_workspace_folder).grid(row=0, column=2, sticky="ew", padx=(12, 0), pady=6)
        self._button(form, "Save", self.save_workspace_from_entry).grid(row=0, column=3, sticky="ew", padx=(8, 0), pady=6)
        self.workspace_text = tk.Label(workspace_card, text=self.workspace_message(), bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 9), anchor="w", wraplength=900, justify="left")
        self.workspace_text.pack(fill="x", padx=24, pady=(0, 18))

        theme_card = self._section_card(body, "2. Theme", "Choose the starting look. Default continues the homepage and launcher style. Seasonal changes automatically. You can still customise and save themes inside the app.")
        theme_card.pack(fill="x", pady=(0, 16))
        theme_row = tk.Frame(theme_card, bg=self.palette["surface"])
        theme_row.pack(fill="x", padx=24, pady=(0, 22))
        self.theme_var = tk.StringVar(value=self.theme_preset)
        self.mode_var = tk.StringVar(value=self.theme_mode)
        ttk.Combobox(theme_row, textvariable=self.theme_var, values=THEME_PRESETS, state="readonly", width=18, style="Pathmark.TCombobox").pack(side="left")
        ttk.Combobox(theme_row, textvariable=self.mode_var, values=THEME_MODES, state="readonly", width=8, style="Pathmark.TCombobox").pack(side="left", padx=(10, 0))
        self._button(theme_row, "Save theme", self.save_theme_choice).pack(side="left", padx=(10, 0))
        self.theme_feedback = tk.Label(theme_row, text="", bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 9))
        self.theme_feedback.pack(side="left", padx=(12, 0))

        action_card = self._section_card(body, "3. Open or update", "Open Pathmark when you are ready. The Update button creates an update backup, opens the download hub, and reminds you to replace only Pathmark_app, not your workspace.")
        action_card.pack(fill="x", pady=(0, 16))
        actions = tk.Frame(action_card, bg=self.palette["surface"])
        actions.pack(fill="x", padx=19, pady=(0, 22))
        self.open_btn = self._button(actions, "Open Pathmark", self.start, primary=True)
        self.update_btn = self._button(actions, "Update", self.backup_and_check_for_updates)
        self.stop_btn = self._button(actions, "Stop app", self.stop_app, disabled=True)
        self.details_btn = self._button(actions, "Show details", self.show_details)
        for i, btn in enumerate([self.open_btn, self.update_btn, self.stop_btn, self.details_btn]):
            btn.grid(row=0, column=i, sticky="ew", padx=5, pady=5)
            actions.grid_columnconfigure(i, weight=1)
        tk.Label(action_card, text="Keep Pathmark_app as the replaceable app folder. A simple location is Documents\\Pathmark_app. Keep your Workspace folder separate and do not replace it during updates.", bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 9), justify="left", anchor="w", wraplength=900).pack(fill="x", padx=24, pady=(0, 18))

        status_card = tk.Frame(body, bg=self.palette["surface"], highlightbackground=self.palette["line"], highlightthickness=1)
        status_card.pack(fill="x", pady=(0, 18))
        self.status = tk.Label(status_card, text="Ready", font=("Segoe UI Variable Display", 18, "bold"), fg=self.palette["text"], bg=self.palette["surface"], anchor="w")
        self.status.pack(fill="x", padx=24, pady=(22, 5))
        self.detail = tk.Label(status_card, text="Confirm your workspace and theme, then open Pathmark.", font=("Segoe UI", 10), fg=self.palette["muted"], bg=self.palette["surface"], anchor="w", wraplength=900, justify="left")
        self.detail.pack(fill="x", padx=24, pady=(0, 16))
        self.progress = ttk.Progressbar(status_card, style="Pathmark.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=24, pady=(0, 18))
        self.progress["value"] = 8
        self.step_labels = []
        steps = tk.Frame(status_card, bg=self.palette["surface"])
        steps.pack(fill="x", padx=24, pady=(0, 20))
        for label in ["Choose workspace", "Check files", "Check Python", "Prepare environment", "Start app"]:
            row = tk.Label(steps, text=f"○ {label}", fg=self.palette["soft"], bg=self.palette["surface"], font=("Segoe UI", 9), anchor="w")
            row.pack(fill="x", pady=2)
            self.step_labels.append(row)

    def workspace_message(self) -> str:
        return f"Current workspace: {USER_ROOT}\nDefault theme: {self.theme_preset} / {self.theme_mode}"

    def refresh_workspace_message(self) -> None:
        try:
            self.workspace_text.config(text=self.workspace_message())
            self.workspace_var.set(str(USER_ROOT))
        except Exception:
            pass

    def save_theme_choice(self) -> None:
        self.theme_preset = normalise_preset(self.theme_var.get() if hasattr(self, "theme_var") else self.theme_preset)
        self.theme_mode = self.mode_var.get() if hasattr(self, "mode_var") else self.theme_mode
        if self.theme_mode not in THEME_MODES:
            self.theme_mode = "Light"
        save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
        self.refresh_workspace_message()
        if hasattr(self, "theme_feedback"):
            self.theme_feedback.config(text=f"Saved: {self.theme_preset} / {self.theme_mode}")
        self.set_status("Theme saved", f"Pathmark will launch with {self.theme_preset} / {self.theme_mode} unless an already-running local app is still open.", 10, 0)

    def save_workspace_from_entry(self) -> None:
        raw = self.workspace_var.get().strip() if hasattr(self, "workspace_var") else ""
        if not raw:
            messagebox.showerror("Workspace required", "Please choose a workspace folder.")
            return
        self.set_workspace(Path(raw), start_after=False)

    def choose_workspace_folder(self) -> None:
        selected = filedialog.askdirectory(title="Choose the workspace Pathmark should use for projects and exports", initialdir=str(USER_ROOT if USER_ROOT.exists() else documents_base()))
        if selected:
            self.workspace_var.set(selected)
            self.set_workspace(Path(selected), start_after=False)

    def set_workspace(self, path: Path, *, start_after: bool = False) -> None:
        set_user_root(path)
        self.theme_preset = normalise_preset(self.theme_var.get() if hasattr(self, "theme_var") else self.theme_preset)
        self.theme_mode = self.mode_var.get() if hasattr(self, "mode_var") else self.theme_mode
        save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
        ensure_user_workspace()
        self.refresh_workspace_message()
        self.set_status("Workspace saved", f"Pathmark will use: {USER_ROOT}", 10, 0)
        if start_after and not self.started:
            self.after(150, self.start)

    def streamlit_env(self) -> dict[str, str]:
        env = os.environ.copy()
        env["PATHMARK_ROOT"] = str(USER_ROOT)
        env["PATHMARK_INITIAL_THEME_PRESET"] = self.theme_preset
        env["PATHMARK_INITIAL_THEME_MODE"] = self.theme_mode
        env["PATHMARK_LAUNCHER_CONFIG"] = str(LAUNCHER_CONFIG)
        env["PATHMARK_SYNC_THEME_FROM_LAUNCHER"] = "1"
        return env

    def current_url(self) -> str:
        return f"http://localhost:{self.port}"

    def mark_step(self, index: int) -> None:
        for i, lab in enumerate(self.step_labels):
            label_text = lab.cget("text").replace("○", "").replace("●", "").strip()
            lab.config(text=("● " if i <= index else "○ ") + label_text, fg=self.palette["accent"] if i < index else (self.palette["text"] if i == index else self.palette["soft"]))

    def set_status(self, status: str, detail: str = "", value: int | None = None, step: int | None = None) -> None:
        self.status.config(text=status)
        self.detail.config(text=detail or status)
        if value is not None:
            self.progress["value"] = value
        if step is not None:
            self.mark_step(step)
        self.update_idletasks()

    def log(self, text: str) -> None:
        self.logs.append(text)
        self.log_queue.put(text)

    def drain_log(self) -> None:
        try:
            while True:
                self.log_queue.get_nowait()
        except queue.Empty:
            pass
        self.after(250, self.drain_log)

    def choose_python(self) -> list[str]:
        for cmd in [["py", "-3"], ["python"]]:
            try:
                subprocess.run(cmd + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True, creationflags=CREATE_NO_WINDOW)
                return cmd
            except Exception:
                continue
        raise FileNotFoundError("Python 3 was not found.")

    def port_free(self, port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            return sock.connect_ex(("127.0.0.1", port)) != 0

    def run_and_log(self, args: list[str], label: str) -> None:
        self.log(f"$ {' '.join(args)}")
        proc = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=CREATE_NO_WINDOW)
        assert proc.stdout is not None
        for line in proc.stdout:
            self.log(line.rstrip())
        code = proc.wait()
        if code != 0:
            raise RuntimeError(f"{label} failed with exit code {code}")

    def start(self) -> None:
        if self.started:
            webbrowser.open(self.current_url())
            return
        raw = self.workspace_var.get().strip() if hasattr(self, "workspace_var") else str(USER_ROOT)
        if not raw:
            messagebox.showerror("Workspace required", "Please choose a workspace folder.")
            return
        set_user_root(Path(raw))
        self.theme_preset = normalise_preset(self.theme_var.get() if hasattr(self, "theme_var") else self.theme_preset)
        self.theme_mode = self.mode_var.get() if hasattr(self, "mode_var") else self.theme_mode
        save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
        self.refresh_workspace_message()
        self.started = True
        self.open_btn.config(state="disabled")
        self.set_status("Opening Pathmark", "Setting up the workspace and checking the local app.", 12, 0)
        threading.Thread(target=self.worker, daemon=True).start()

    def worker(self) -> None:
        try:
            if os.name != "nt":
                raise RuntimeError("This local launcher is currently Windows-only. Use the Streamlit app directly on non-Windows systems.")
            ensure_user_workspace()
            save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
            self.after(0, self.refresh_workspace_message)
            self.set_status("Checking app files", "Looking for the Pathmark app files.", 20, 1)
            if not APP_FILE.exists():
                raise FileNotFoundError(f"Missing app file: {APP_FILE}")
            if not REQUIREMENTS.exists():
                raise FileNotFoundError(f"Missing requirements file: {REQUIREMENTS}")
            self.set_status("Checking Python", "Pathmark uses Python to run the local app.", 34, 2)
            py_cmd = self.choose_python()
            self.set_status("Preparing the local environment", "This is only needed the first time this copy of Pathmark is run.", 48, 3)
            if not VENV_PYTHON.exists():
                self.run_and_log(py_cmd + ["-m", "venv", str(VENV)], "Create environment")
            self.set_status("Installing app requirements", "This may take a minute the first time. You can watch this section rather than guessing whether anything is happening.", 64, 3)
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], "Upgrade pip")
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], "Install requirements")
            if not self.port_free(DEFAULT_PORT):
                self.port = DEFAULT_PORT
                self.set_status("Pathmark is already running", f"Opening the existing app at {self.current_url()}. If a previous theme is still showing, close the old local app process and open Pathmark again.", 100, 4)
                self.after(350, lambda: webbrowser.open(self.current_url()))
                self.after(0, lambda: self.open_btn.config(state="normal", text="Open existing app"))
                return
            self.port = DEFAULT_PORT
            self.set_status("Starting Pathmark", "Opening the local app in your browser.", 84, 4)
            self.proc = subprocess.Popen([str(VENV_PYTHON), "-m", "streamlit", "run", str(APP_FILE), "--server.port", str(self.port), "--server.headless", "true", "--browser.gatherUsageStats", "false"], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=CREATE_NO_WINDOW, env=self.streamlit_env())
            self.after(1400, lambda: webbrowser.open(self.current_url()))
            self.after(0, lambda: (self.set_status("Pathmark is running", f"The app is open at {self.current_url()}", 100, 4), self.open_btn.config(state="normal", text="Open Pathmark in browser"), self.stop_btn.config(state="normal")))
            assert self.proc.stdout is not None
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except FileNotFoundError as exc:
            self.log(str(exc))
            self.set_status("Python is needed", "Install Python 3.11 or later, then open Pathmark again.", 100)
            messagebox.showerror("Python is needed", "Python 3 was not found. Please install Python 3.11 or later, then open Pathmark again.")
            webbrowser.open("https://www.python.org/downloads/")
            self.after(0, lambda: self.open_btn.config(state="normal"))
            self.started = False
        except Exception as exc:
            self.log(str(exc))
            self.set_status("Pathmark could not start", str(exc), 100)
            messagebox.showerror("Pathmark could not start", str(exc))
            self.after(0, lambda: self.open_btn.config(state="normal"))
            self.started = False

    def show_details(self) -> None:
        win = tk.Toplevel(self)
        win.title("Pathmark details")
        win.geometry("820x480")
        text = ScrolledText(win, wrap="word")
        text.pack(fill="both", expand=True)
        text.insert("1.0", "\n".join(self.logs) if self.logs else "No technical details yet.")
        text.config(state="disabled")

    def create_update_backup(self) -> Path | None:
        try:
            raw = self.workspace_var.get().strip() if hasattr(self, "workspace_var") else str(USER_ROOT)
            if raw:
                set_user_root(Path(raw))
            ensure_user_workspace()
            save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
            USER_BACKUPS.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            backup_path = USER_BACKUPS / f"pathmark_update_backup_{stamp}.zip"
            with zipfile.ZipFile(backup_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
                if USER_DB.exists():
                    z.write(USER_DB, "pathmark.db")
                if LAUNCHER_CONFIG.exists():
                    z.write(LAUNCHER_CONFIG, "pathmark_launcher_settings.json")
                workspace_launcher_settings = USER_SYSTEM / "pathmark_launcher_settings.json"
                if workspace_launcher_settings.exists():
                    z.write(workspace_launcher_settings, "workspace_pathmark_launcher_settings.json")
                z.writestr("README.txt", f"Backup created by Pathmark before updating.\nWorkspace: {USER_ROOT}\nTheme: {self.theme_preset} / {self.theme_mode}\n")
            self.log(f"Update backup created: {backup_path}")
            return backup_path
        except Exception as exc:
            self.log(f"Update backup failed: {exc}")
            messagebox.showerror("Update backup failed", str(exc))
            return None

    def backup_and_check_for_updates(self) -> None:
        backup = self.create_update_backup()
        if backup:
            self.set_status("Update backup created", f"Backup saved to {backup}. The update hub is opening now. Replace only Pathmark_app; keep your Workspace folder.", 100, 0)
        webbrowser.open(RELEASE_HUB_URL)

    def stop_app(self) -> None:
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                pass
        self.destroy()

    def on_close(self) -> None:
        self.stop_app()


if __name__ == "__main__":
    Launcher().mainloop()
