from __future__ import annotations

import os
import queue
import socket
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk

APP_NAME = "Pathmark"
APP_VERSION = "Local App v0.5.36"
DEFAULT_PORT = 8545
RELEASE_HUB_URL = "https://pathmark.streamlit.app/"


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


ROOT = app_root()
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "bin" / "python"
ICON = ROOT / "assets" / "pathmark.png"
ICON_PNG = ROOT / "assets" / "pathmark.png"
CREATE_NO_WINDOW = 0


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("840x560")
        self.minsize(760, 520)
        self.proc: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.logs: list[str] = []
        self.port = DEFAULT_PORT
        self.started = False
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.palette = {
            "bg": "#F7F6F2",
            "bg2": "#FBFAF7",
            "surface": "#FFFFFF",
            "surface2": "#EFEEE8",
            "text": "#1F2221",
            "muted": "#626966",
            "soft": "#8A918E",
            "accent": "#334E68",
            "accent2": "#7A4E7A",
            "accent_soft": "#E7EEF4",
            "warm": "#A66A43",
            "success": "#255833",
            "line": "#D8D4CB",
            "cream": "#F6F4EF",
        }
        self.configure(bg=self.palette["bg"])
        self._style()
        self._build_ui()
        self.after(150, self.drain_log)
        self.after(550, self.start)

    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(
            "Pathmark.Horizontal.TProgressbar",
            troughcolor=self.palette["surface2"],
            background=self.palette["warm"],
            bordercolor=self.palette["surface2"],
            lightcolor=self.palette["warm"],
            darkcolor=self.palette["warm"],
            thickness=12,
        )

    def _button(self, parent, text, command, *, primary=False, disabled=False):
        btn = tk.Button(
            parent,
            text=text,
            command=command,
            state="disabled" if disabled else "normal",
            bg=self.palette["accent"] if primary else self.palette["surface2"],
            fg="#FFFFFF" if primary else self.palette["text"],
            activebackground="#466782" if primary else "#E4E1D9",
            activeforeground="#FFFFFF" if primary else self.palette["text"],
            disabledforeground="#7A7E7B",
            relief="flat",
            padx=18,
            pady=11,
            font=("Segoe UI", 10, "bold" if primary else "normal"),
            cursor="hand2",
        )
        return btn

    def _draw_header_bg(self, canvas: tk.Canvas) -> None:
        # Soft product-page-inspired background: pale canvas with subtle accent circles.
        w, h = 840, 205
        canvas.create_rectangle(0, 0, w, h, fill=self.palette["bg2"], outline="")
        canvas.create_oval(-90, -120, 330, 260, fill="#E7EEF4", outline="")
        canvas.create_oval(610, -100, 1030, 230, fill="#F0E8F1", outline="")
        canvas.create_rectangle(0, h - 1, w, h, fill=self.palette["line"], outline="")

    def _make_logo_label(self, parent, size: int = 84) -> tk.Widget:
        frame = tk.Frame(parent, width=size, height=size, bg=self.palette["bg2"])
        frame.pack_propagate(False)
        self.logo_image = None
        if ICON_PNG.exists():
            try:
                raw = tk.PhotoImage(file=str(ICON_PNG))
                factor = max(1, raw.width() // size)
                self.logo_image = raw.subsample(factor, factor)
                return tk.Label(frame, image=self.logo_image, bg=self.palette["bg2"])
            except Exception:
                self.logo_image = None
        fallback = tk.Canvas(frame, width=size, height=size, bg=self.palette["bg2"], highlightthickness=0)
        fallback.create_oval(8, 8, size-8, size-8, fill="#182A27", outline="")
        fallback.create_line(size*.30, size*.68, size*.44, size*.51, size*.58, size*.58, size*.72, size*.34, fill="#F6F4EF", width=max(4, size//11), smooth=True)
        return fallback

    def _build_ui(self) -> None:
        # Header visually follows the Streamlit release hub: large title, light background, pill label.
        header = tk.Canvas(self, height=205, bg=self.palette["bg2"], highlightthickness=0)
        header.pack(fill="x")
        self._draw_header_bg(header)

        header_inner = tk.Frame(header, bg=self.palette["bg2"])
        header.create_window(36, 28, window=header_inner, anchor="nw", width=760)

        badge = tk.Label(
            header_inner,
            text="Starting local app",
            bg=self.palette["accent_soft"],
            fg=self.palette["accent"],
            padx=12,
            pady=6,
            font=("Segoe UI", 9, "bold"),
        )
        badge.pack(anchor="w", pady=(0, 12))

        title_row = tk.Frame(header_inner, bg=self.palette["bg2"])
        title_row.pack(fill="x")
        logo_frame = tk.Frame(title_row, bg=self.palette["bg2"], width=84, height=84)
        logo_frame.pack(side="left", padx=(0, 18))
        logo_frame.pack_propagate(False)
        logo_widget = self._make_logo_label(logo_frame, 84)
        logo_widget.pack(expand=True)

        title_block = tk.Frame(title_row, bg=self.palette["bg2"])
        title_block.pack(side="left", fill="both", expand=True)
        tk.Label(
            title_block,
            text="Pathmark",
            font=("Segoe UI Variable Display", 45, "bold"),
            fg="#111614",
            bg=self.palette["bg2"],
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            title_block,
            text="Make time for routines. Reduce friction with prompts. Keep goals moving.",
            font=("Segoe UI", 11, "bold"),
            fg="#1F2221",
            bg=self.palette["bg2"],
            anchor="w",
        ).pack(fill="x", pady=(4, 0))

        body = tk.Frame(self, bg=self.palette["bg"])
        body.pack(fill="both", expand=True, padx=34, pady=28)

        content = tk.Frame(body, bg=self.palette["bg"])
        content.pack(fill="both", expand=True)

        left = tk.Frame(content, bg=self.palette["bg"])
        left.pack(side="left", fill="both", expand=True, padx=(0, 18))
        right = tk.Frame(content, bg=self.palette["bg"])
        right.pack(side="left", fill="y")

        card = tk.Frame(left, bg=self.palette["surface"], highlightbackground=self.palette["line"], highlightthickness=1)
        card.pack(fill="x")

        self.status = tk.Label(
            card,
            text="Preparing Pathmark",
            font=("Segoe UI Variable Display", 18, "bold"),
            fg=self.palette["text"],
            bg=self.palette["surface"],
            anchor="w",
        )
        self.status.pack(fill="x", padx=24, pady=(24, 5))

        self.detail = tk.Label(
            card,
            text="Checking the Pathmark app files.",
            font=("Segoe UI", 10),
            fg=self.palette["muted"],
            bg=self.palette["surface"],
            anchor="w",
            wraplength=485,
            justify="left",
        )
        self.detail.pack(fill="x", padx=24, pady=(0, 18))

        self.progress = ttk.Progressbar(card, style="Pathmark.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=24, pady=(0, 22))
        self.progress["value"] = 5

        self.step_labels = []
        steps = tk.Frame(card, bg=self.palette["surface"])
        steps.pack(fill="x", padx=24, pady=(0, 24))
        for label in ["Check files", "Check Python", "Prepare environment", "Start app"]:
            row = tk.Label(steps, text=f"○ {label}", fg=self.palette["soft"], bg=self.palette["surface"], font=("Segoe UI", 9), anchor="w")
            row.pack(fill="x", pady=2)
            self.step_labels.append(row)

        help_card = tk.Frame(left, bg=self.palette["surface2"], highlightbackground=self.palette["line"], highlightthickness=1)
        help_card.pack(fill="x", pady=(16, 0))
        tk.Label(help_card, text="This opens Pathmark locally in your browser.", bg=self.palette["surface2"], fg=self.palette["text"], font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x", padx=18, pady=(14, 2))
        tk.Label(help_card, text="You can close this launcher when you are finished, or leave it open while you work.", bg=self.palette["surface2"], fg=self.palette["muted"], font=("Segoe UI", 9), anchor="w", wraplength=510, justify="left").pack(fill="x", padx=18, pady=(0, 14))

        action_card = tk.Frame(right, width=230, bg=self.palette["surface"], highlightbackground=self.palette["line"], highlightthickness=1)
        action_card.pack(fill="y")
        action_card.pack_propagate(False)
        tk.Label(action_card, text="Actions", bg=self.palette["surface"], fg=self.palette["text"], font=("Segoe UI", 13, "bold"), anchor="w").pack(fill="x", padx=18, pady=(20, 8))
        self.open_btn = self._button(action_card, "Open Pathmark", lambda: webbrowser.open(self.current_url()), primary=True, disabled=True)
        self.open_btn.pack(fill="x", padx=18, pady=(4, 8))
        self.stop_btn = self._button(action_card, "Stop app", self.stop_app, disabled=True)
        self.stop_btn.pack(fill="x", padx=18, pady=8)
        self.details_btn = self._button(action_card, "Show details", self.show_details)
        self.details_btn.pack(fill="x", padx=18, pady=8)
        self.update_btn = self._button(action_card, "Check for updates", self.check_for_updates)
        self.update_btn.pack(fill="x", padx=18, pady=8)
        tk.Label(action_card, text=f"{APP_VERSION}\nRuns locally on this computer", bg=self.palette["surface"], fg=self.palette["soft"], font=("Segoe UI", 8), justify="left", anchor="w").pack(side="bottom", fill="x", padx=18, pady=18)

    def current_url(self) -> str:
        return f"http://localhost:{self.port}"

    def mark_step(self, index: int) -> None:
        for i, lab in enumerate(self.step_labels):
            label_text = lab.cget("text").replace("○", "").replace("●", "").strip()
            if i < index:
                lab.config(text=f"● {label_text}", fg=self.palette["accent"])
            elif i == index:
                lab.config(text=f"● {label_text}", fg=self.palette["text"])
            else:
                lab.config(text=f"○ {label_text}", fg=self.palette["soft"])

    def set_status(self, status: str, detail: str = "", value: int | None = None, step: int | None = None) -> None:
        self.status.config(text=status)
        self.detail.config(text=detail or status)
        if value is not None:
            self.progress["value"] = value
        if step is not None:
            self.mark_step(step)
        self.update_idletasks()

    def log(self, text: str) -> None:
        self.logs.append(text)
        self.log_queue.put(text)

    def drain_log(self) -> None:
        try:
            while True:
                self.log_queue.get_nowait()
        except queue.Empty:
            pass
        self.after(250, self.drain_log)

    def choose_python(self) -> list[str]:
        candidates = [["python3"], ["python"]]
        for cmd in candidates:
            try:
                subprocess.run(cmd + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
                return cmd
            except Exception:
                continue
        raise FileNotFoundError("Python 3 was not found.")

    def port_free(self, port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            return sock.connect_ex(("127.0.0.1", port)) != 0

    def choose_port(self) -> int:
        for port in range(DEFAULT_PORT, DEFAULT_PORT + 25):
            if self.port_free(port):
                return port
        return DEFAULT_PORT

    def run_and_log(self, args: list[str], label: str) -> None:
        self.log(f"$ {' '.join(args)}")
        proc = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        assert proc.stdout is not None
        for line in proc.stdout:
            self.log(line.rstrip())
        code = proc.wait()
        if code != 0:
            raise RuntimeError(f"{label} failed with exit code {code}")

    def start(self) -> None:
        if self.started:
            return
        self.started = True
        threading.Thread(target=self.worker, daemon=True).start()

    def worker(self) -> None:
        try:
            self.set_status("Checking app files", "Looking for the Pathmark app files.", 10, 0)
            if not APP_FILE.exists():
                raise FileNotFoundError(f"Missing app file: {APP_FILE}")
            if not REQUIREMENTS.exists():
                raise FileNotFoundError(f"Missing requirements file: {REQUIREMENTS}")

            self.set_status("Checking Python", "Pathmark uses Python to run the local app.", 24, 1)
            py_cmd = self.choose_python()

            self.set_status("Creating local environment", "This is only needed the first time the app is run.", 42, 2)
            if not VENV_PYTHON.exists():
                self.run_and_log(py_cmd + ["-m", "venv", str(VENV)], "Create environment")

            self.set_status("Installing app requirements", "This may take a minute the first time.", 62, 2)
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], "Upgrade pip")
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], "Install requirements")

            self.port = self.choose_port()
            self.set_status("Starting Pathmark", "Opening the local app in your browser.", 84, 3)
            self.proc = subprocess.Popen(
                [str(VENV_PYTHON), "-m", "streamlit", "run", str(APP_FILE), "--server.port", str(self.port)],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            self.after(1400, lambda: webbrowser.open(self.current_url()))
            self.after(0, lambda: (
                self.set_status("Pathmark is running", f"The app is open at {self.current_url()}", 100, 4),
                self.open_btn.config(state="normal"),
                self.stop_btn.config(state="normal"),
            ))
            assert self.proc.stdout is not None
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except FileNotFoundError as exc:
            self.log(str(exc))
            self.set_status("Python is needed", "Install Python 3.11 or later, then open Pathmark again.", 100)
            messagebox.showerror("Python is needed", "Python 3 was not found. Please install Python 3.11 or later, then open Pathmark again.")
            webbrowser.open("https://www.python.org/downloads/macos/")
        except Exception as exc:
            self.log(str(exc))
            self.set_status("Pathmark could not start", str(exc), 100)
            messagebox.showerror("Pathmark could not start", str(exc))

    def show_details(self) -> None:
        win = tk.Toplevel(self)
        win.title("Pathmark details")
        win.geometry("820x480")
        text = ScrolledText(win, wrap="word")
        text.pack(fill="both", expand=True)
        text.insert("1.0", "\n".join(self.logs))
        text.config(state="disabled")

    def check_for_updates(self) -> None:
        webbrowser.open(RELEASE_HUB_URL)

    def stop_app(self) -> None:
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                pass
        self.destroy()

    def on_close(self) -> None:
        self.stop_app()


if __name__ == "__main__":
    Launcher().mainloop()
