# Pathmark Mac app source

This folder contains the local Mac version of Pathmark.

Move the full `Pathmark_app` folder into the user's Pathmark folder, for example:

```text
~/Documents/Pathmark/Pathmark_app
```

Open `Start Pathmark.command` to run Pathmark locally.


## Launcher appearance

If Pathmark still opens with the old dark launcher, delete the old `Pathmark.exe` and run `build_launcher_exe.bat` again. The executable is built from the current launcher source, so an older compiled EXE will not update by itself.
