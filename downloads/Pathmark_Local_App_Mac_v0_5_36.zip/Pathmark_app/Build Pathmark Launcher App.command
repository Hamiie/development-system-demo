#!/bin/zsh
set -e
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed. Install Python 3 from python.org, then run this again."
  open "https://www.python.org/downloads/macos/"
  exit 1
fi
python3 -m venv .build_venv
source .build_venv/bin/activate
python -m pip install --upgrade pip
python -m pip install pyinstaller
pyinstaller --noconfirm --windowed --name "Start Pathmark" PathmarkMacLauncher.py
echo ""
echo "Created: dist/Start Pathmark.app"
echo "Copy this app into the Pathmark_app folder if you want an app-style launcher."
read -k 1 "?Press any key to close."
