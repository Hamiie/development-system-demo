# Clearway Local App — build first

This is the local Clearway app package. It runs as a local Streamlit app in your browser so it can work with your own folders, Markdown files, backups, tasklists, Google Calendar exports, and Google Tasks exports.

## Important: build the launcher first

This source package does **not** include a prebuilt `Start Clearway.exe`, because old executables can become stale.

Before publishing or sharing the Windows app package, run:

```bat
build_launcher_exe.bat
```

This creates:

```text
Start Clearway.exe
```

Then run:

```bat
package_for_cloud_download.bat
```

This creates the local app zip to place in the Streamlit release hub downloads folder.

## Fallback launcher

`Start Clearway.cmd` is included as a fallback. It launches the same local Streamlit app, but it is less polished than the EXE launcher.

## Default local folder

New users are guided toward:

```text
Documents\Clearway
```

Existing users can select an existing folder, including an older `Documents\Development` folder.

## Safe file behaviour

Clearway may create missing folders and Markdown files. It must not delete, empty, or rename existing folders. Markdown files are backed up before being updated.

Persistent user data should live outside the replaceable app folder:

```text
Clearway\
    00_System\
        clearway.db
        Tasklists\
        Google Calendar Exports\
        Google Tasks Exports\
        Backups\
    01_Body_And_Stability\
    02_Home_And_Garden\
    local_app\   <- replaceable app files
```

## Google Tasks import setup

Clearway can export Google Tasks prompts as CSV files, but Google Tasks does not have a normal CSV import button.

To set this up, use either:

- `Start Google Tasks Setup Helper.cmd`
- `docs/Google Tasks Import Setup.md`

The setup creates a Google Sheet importer using Google Apps Script. The app also writes a copy of the setup guide and Apps Script file into:

`00_System\Google Tasks Exports`

The setup is only needed once per Google account.
