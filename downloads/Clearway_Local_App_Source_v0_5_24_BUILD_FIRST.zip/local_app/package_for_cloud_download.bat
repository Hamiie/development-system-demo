@echo off
setlocal
cd /d "%~dp0"
title Package Clearway Local App Source

echo Creating source package without a prebuilt EXE.
echo Run build_launcher_exe.bat first only when preparing a friend-facing package.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$out='Clearway_Local_App_Source_v0_5_23_BUILD_FIRST.zip'; if(Test-Path $out){Remove-Item $out -Force}; $items=@('Start Clearway.cmd','DevelopmentSystemLauncher.py','build_launcher_exe.bat','package_for_cloud_download.bat','app','config','docs','requirements.txt','README.md','README - Start Here.md','Start Google Tasks Setup Helper.cmd','tools') | Where-Object { Test-Path $_ }; Compress-Archive -Path $items -DestinationPath $out -Force"

echo.
echo Created Clearway_Local_App_Source_v0_5_23_BUILD_FIRST.zip
echo This source package does not include Start Clearway.exe.
pause
