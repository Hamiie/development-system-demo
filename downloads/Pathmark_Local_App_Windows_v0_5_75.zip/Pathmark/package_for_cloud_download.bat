@echo off
setlocal
cd /d "%~dp0"
title Package Pathmark Windows App

echo Creating Windows package without a prebuilt EXE.
echo Run build_launcher_exe.bat first to create Pathmark.exe if you want the launcher included.
echo.

cd ..
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$out='Pathmark_Local_App_Windows_v0_5_53.zip'; if(Test-Path $out){Remove-Item $out -Force}; Compress-Archive -Path 'Pathmark' -DestinationPath $out -Force"

echo.
echo Created Pathmark_Local_App_Windows_v0_5_53.zip
echo This package contains the Pathmark folder.
pause
