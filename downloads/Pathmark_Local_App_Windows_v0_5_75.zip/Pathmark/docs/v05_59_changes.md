# v0.5.60 changes

- Changed the launcher button from Update to Check for updates.
- The launcher now compares the installed app version with the release hub version before opening the download page.
- If a newer version is available, Pathmark can create an update backup of Workspace settings and database before opening the download page.
- Refreshed homepage copy around Routines. Prompts. Progress.
