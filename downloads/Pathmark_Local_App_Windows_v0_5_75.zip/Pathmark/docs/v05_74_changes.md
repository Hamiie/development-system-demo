# v0.5.74 changes

This package is paired with the v0.5.74 release hub update.

- The release hub now includes a `supabase/migrations/` folder for the hosted access-control schema.
- The migration creates only the hosted role, feature-flag, and audit-log tables.
- RLS is enabled in the migration, and no public policies are created.
- Personal developer rows, private emails, Supabase keys, Google OAuth secrets, and Streamlit secrets remain outside GitHub.
- No local Workspace data model change was made in this local package.
