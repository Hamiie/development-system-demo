# v0.5.52 changes

- Revised the public download page wording so it explains the app in process-focused, user-facing language.
- Kept the homepage focused on Areas, routines, prompts, exports, and the local Workspace rather than broad emotional promises.
- Softened the launcher cards and controls so the launcher feels closer to the Pathmark homepage.
- Removed the Custom theme option from the launcher setup. Custom themes remain available inside the app.
- Theme choices in the launcher now use colour swatches, and Light/Dark mode choices update the preview.
