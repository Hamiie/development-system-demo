# v0.5.39 changes

- Windows-only release package restored to the original release-hub repository structure.
- Mac download/package removed from the release hub for now.
- Launcher keeps Backup local data and Backup and check updates actions.
- Streamlit launches in headless mode to avoid duplicate browser windows.
- User data and exports default to Documents\Pathmark rather than Downloads.
- Export folders are grouped under 00_System: Tasklists, Google Calendar Exports, Google Tasks Exports, and Backups.
- Existing top-level folders in the selected Pathmark folder are detected as Areas.
