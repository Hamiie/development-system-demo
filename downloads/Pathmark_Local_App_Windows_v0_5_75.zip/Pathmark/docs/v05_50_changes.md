# v0.5.52 changes

- Improved the public release hub so it explains Pathmark in clearer user-facing language.
- Softened the launcher layout so it feels less like a utility grid and more like the Pathmark homepage.
- Reinforced numbered Area folder detection. Area import now requires folders such as `01_Body_And_Stability`; unnumbered folders are ignored.
- Added a more reliable cleanup for older automatically imported app/system folders that appeared as Areas.
- Reinforced Default theme contrast for button text.
