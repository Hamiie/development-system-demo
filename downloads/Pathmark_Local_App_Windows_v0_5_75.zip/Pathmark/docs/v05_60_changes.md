# v0.5.60 changes

- Simplified the launcher so it focuses on Workspace selection and update checks.
- Theme selection now happens inside the app rather than in the launcher.
- Reordered the sidebar to follow the workflow: Home, Review Queue, Areas, Routines, Goals, Tasklist, exports, Settings.
- Removed the review-check button from Home; review checks live on the Review Queue page.
- Simplified the Areas page and removed visible folder path and Markdown path fields.
- Specific area fields now offer existing locations inside the selected Area and can create a new specific area when saving.
- Goal and routine Markdown files are generated quietly when saving goals and routines.
- Reframed standard routines as optional suggested starter routines.
- Tightened Review Queue filtering so unnumbered and system folders are ignored.
