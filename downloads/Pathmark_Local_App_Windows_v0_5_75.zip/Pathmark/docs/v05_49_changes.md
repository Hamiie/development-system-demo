# v0.5.49 changes

- Archived older auto-imported Areas that came from unnumbered Workspace folders. Area detection now requires a numeric prefix such as `01_Body_And_Stability`; `00_System` is reserved and ignored.
- Area selectors and the Areas page now show active Areas only.
- Strengthened Default theme button-text contrast in the Streamlit app.
- Reworked the launcher theme controls into rounded pill buttons rather than square dropdown controls.
- Kept the public homepage more focused on download, installation, and update instructions rather than repeating the same introductory message.
