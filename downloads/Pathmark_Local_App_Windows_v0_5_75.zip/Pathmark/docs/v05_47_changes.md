# v0.5.47 changes

- Area import now only recognises numbered top-level folders such as `01_Body_And_Stability`.
- `00_System` and unnumbered folders are ignored so app folders, export folders, and random user folders do not appear as Areas.
- The default theme button styling has stronger text contrast, including button label text rendered inside Streamlit buttons.
