# v0.5.66 changes

- Tightened hosted login and role checks before wider beta testing.
- Developer bootstrap emails now belong in Streamlit secrets rather than public source code.
- Beta/developer hosted tools require a verified email claim from the login provider.
- Google Sheets on-the-go sync now centres on creating a Pathmark sync sheet from the hosted page.
- Existing sync sheet entry is treated as an advanced/testing path.
- Role store wording now makes clear that it stores access records only, not Pathmark planning data.
