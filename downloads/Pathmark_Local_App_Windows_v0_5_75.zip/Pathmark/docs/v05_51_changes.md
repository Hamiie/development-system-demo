# v0.5.52 changes

- Renamed the replaceable app folder in the Windows package from `Pathmark_app` to `Pathmark`.
- Updated installation and update instructions so the app can live at `Documents\Pathmark` while the default user workspace remains `Documents\Workspace`.
- Clarified that the Workspace is the folder for projects, numbered Areas, exports, backups, tasklists, and the local database.
- Updated README wording so Areas are described as numbered folders only; ordinary unnumbered folders are ignored.
