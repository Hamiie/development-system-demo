# v0.5.64 changes

- Added optional user-authorised Google OAuth for hosted On the go capture.
- Removed the service-account sharing wording from the hosted page.
- Kept CSV capture/import as the safe fallback.
- Added desktop Google Sheets OAuth support using a user-selected Google OAuth desktop client JSON file.
- When connected, desktop Pathmark can mark imported/rejected sync rows back on the user-owned Google Sheet.
