# v0.5.55 changes

- Restores the hosted release hub homepage after v0.5.54 accidentally deployed the local app as the public homepage.
- Keeps the PyYAML dependency fix from v0.5.54.
