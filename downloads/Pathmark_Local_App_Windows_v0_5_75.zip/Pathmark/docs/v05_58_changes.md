# v0.5.58 changes

- Removed the Area-folder helper text that was being rendered at the top of the app page.
- Kept Area folder detection strict: numbered folders only, excluding `00_System`.
- Retained the `Documents\Pathmark` app folder and `Documents\Workspace` default Workspace model.
