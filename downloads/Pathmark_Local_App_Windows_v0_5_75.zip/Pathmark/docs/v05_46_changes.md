# v0.5.46 changes

- Restyled the Windows launcher as a scrollable, homepage-aligned workflow rather than a dense control panel.
- Removed the first-launch pop-up. Workspace guidance now appears inside the launcher itself.
- The launcher no longer auto-starts the app before the user can review the workspace and theme.
- Added a clearer three-step launcher flow: Workspace, Theme, Open or update.
- Kept a single launcher Update action. It creates an update backup and opens the update hub.
- Updated installation wording so `Pathmark` can live directly in Documents, while the default workspace remains `Documents\Workspace`.
