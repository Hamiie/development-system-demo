# v0.5.65 changes

- Hosted release hub now supports login/profile gating for beta and developer features.
- Public visitors see the download/update homepage only.
- Unknown signed-in users default to standard access.
- On-the-go beta and Google Sheets OAuth tools are hidden unless the user is a beta tester or developer.
- Developer role management is available when a private role-store sheet is configured on the hosted deployment.
