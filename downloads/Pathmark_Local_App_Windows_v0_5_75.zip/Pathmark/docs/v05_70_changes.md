# v0.5.70 changes

- Hosted login now uses a Pathmark-managed Google OAuth flow instead of Streamlit `st.login()`, avoiding the Streamlit Authlib route error.
- The hosted homepage no longer shows the extra download-only/status bar.
- Google sign-in still uses Google OAuth; Pathmark does not collect or store passwords.
- Beta/developer tools remain hidden unless the signed-in Google email is verified and has the appropriate role.
