# v0.5.53 changes

- Fixed in-app theme changes being overwritten by launcher theme sync on Streamlit reruns.
- Added automatic contrast checks for theme text, button labels, input text, placeholders, tags, and dropdown menus.
- Area folder import now chooses unused Google Calendar colours where possible.
- Numbered folder-only Area detection remains enforced; 00_System is reserved and ignored.
