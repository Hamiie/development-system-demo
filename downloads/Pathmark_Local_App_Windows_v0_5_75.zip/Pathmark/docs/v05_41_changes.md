# v0.5.41 changes

- Separated the replaceable app folder from the user workspace folder.
- The launcher now creates/uses `Documents\Pathmark` by default and can point Pathmark to a custom workspace folder.
- The launcher explains that the workspace folder is used for projects, area folders, exports, tasklists, and backups.
- The launcher passes the selected workspace folder to the local Streamlit app using `PATHMARK_ROOT`.
- The release-hub instructions no longer assume `Documents\Pathmark` already exists before installation.
