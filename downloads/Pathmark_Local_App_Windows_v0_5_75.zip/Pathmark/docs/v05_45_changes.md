# v0.5.45 changes

- App files are now documented as living at `Documents\Pathmark`.
- The default user Workspace is consistently `Documents\Workspace`.
- Homepage installation steps use Markdown rather than raw HTML code tags.
- The redundant suggested organisation section was removed from the homepage.
- Update wording now tells users to replace only `Pathmark` and not the Workspace folder.
