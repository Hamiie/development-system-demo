from __future__ import annotations

import os
import queue
import socket
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk

APP_NAME = "Pathmark"
APP_VERSION = "Local App v0.5.33"
DEFAULT_PORT = 8545
RELEASE_HUB_URL = "https://pathmark.streamlit.app/"


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


ROOT = app_root()
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "bin" / "python"
ICON = ROOT / "assets" / "pathmark.png"
CREATE_NO_WINDOW = 0


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("700x500")
        self.minsize(640, 460)
        self.proc: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.logs: list[str] = []
        self.port = DEFAULT_PORT
        self.started = False
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.palette = {
            "bg": "#F6F4EF",
            "surface": "#FFFFFF",
            "surface2": "#ECE8DF",
            "text": "#1F2221",
            "muted": "#626966",
            "soft": "#858C88",
            "accent": "#1D7F74",
            "accent2": "#63D5C7",
            "ink_on_accent": "#FFFFFF",
            "border": "#D8D4CB",
            "shadow": "#DAD5CA",
            "danger": "#A33D6A",
        }
        self.configure(bg=self.palette["bg"])
        self._style()
        self._build_ui()
        self.after(150, self.drain_log)
        self.after(550, self.start)

    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(
            "Pathmark.Horizontal.TProgressbar",
            troughcolor=self.palette["surface2"],
            background=self.palette["accent"],
            bordercolor=self.palette["surface2"],
            lightcolor=self.palette["accent2"],
            darkcolor=self.palette["accent"],
            thickness=14,
        )

    def _button(self, parent, text, command, *, primary=False, disabled=False):
        btn = tk.Button(
            parent,
            text=text,
            command=command,
            state="disabled" if disabled else "normal",
            bg=self.palette["accent"] if primary else self.palette["surface2"],
            fg=self.palette["ink_on_accent"] if primary else self.palette["text"],
            activebackground=self.palette["accent2"] if primary else "#E2DED5",
            activeforeground=self.palette["text"] if primary else self.palette["text"],
            disabledforeground=self.palette["soft"],
            relief="flat",
            padx=18,
            pady=10,
            font=("Segoe UI", 10, "bold" if primary else "normal"),
            cursor="hand2",
        )
        return btn

    def _build_ui(self) -> None:
        outer = tk.Frame(self, bg=self.palette["bg"])
        outer.pack(fill="both", expand=True, padx=28, pady=26)

        hero = tk.Frame(outer, bg=self.palette["bg"])
        hero.pack(fill="x")

        logo_frame = tk.Frame(hero, width=52, height=52, bg=self.palette["bg"])
        logo_frame.pack(side="left", padx=(0, 14))
        logo_frame.pack_propagate(False)
        self.logo_image = None
        if ICON.exists():
            try:
                raw_logo = tk.PhotoImage(file=str(ICON))
                self.logo_image = raw_logo.subsample(max(1, raw_logo.width() // 48), max(1, raw_logo.height() // 48))
                tk.Label(logo_frame, image=self.logo_image, bg=self.palette["bg"]).pack(expand=True)
            except Exception:
                self.logo_image = None
        if self.logo_image is None:
            fallback = tk.Canvas(logo_frame, width=52, height=52, bg=self.palette["bg"], highlightthickness=0)
            fallback.pack(expand=True)
            fallback.create_oval(7, 7, 45, 45, fill="#102522", outline="")
            fallback.create_text(26, 26, text="P", fill="#F6F4EF", font=("Segoe UI", 22, "bold"))

        title_block = tk.Frame(hero, bg=self.palette["bg"])
        title_block.pack(side="left", fill="x", expand=True)
        tk.Label(
            title_block,
            text="Pathmark",
            font=("Segoe UI Variable Display", 25, "bold"),
            fg=self.palette["text"],
            bg=self.palette["bg"],
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            title_block,
            text="Make time for routines. Reduce friction with prompts. Keep goals moving.",
            font=("Segoe UI", 10),
            fg=self.palette["muted"],
            bg=self.palette["bg"],
            anchor="w",
            justify="left",
        ).pack(fill="x", pady=(3, 0))

        card = tk.Frame(outer, bg=self.palette["surface"], highlightbackground=self.palette["border"], highlightthickness=1)
        card.pack(fill="x", pady=(24, 18))

        self.status = tk.Label(
            card,
            text="Preparing Pathmark",
            font=("Segoe UI Variable Display", 16, "bold"),
            fg=self.palette["text"],
            bg=self.palette["surface"],
            anchor="w",
        )
        self.status.pack(fill="x", padx=22, pady=(20, 4))

        self.detail = tk.Label(
            card,
            text="Checking the Pathmark app files.",
            font=("Segoe UI", 10),
            fg=self.palette["muted"],
            bg=self.palette["surface"],
            anchor="w",
            wraplength=600,
            justify="left",
        )
        self.detail.pack(fill="x", padx=22, pady=(0, 16))

        self.progress = ttk.Progressbar(card, style="Pathmark.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=22, pady=(0, 20))
        self.progress["value"] = 5

        steps = tk.Frame(card, bg=self.palette["surface"])
        steps.pack(fill="x", padx=22, pady=(0, 20))
        self.step_labels = []
        for text in ["Check files", "Check Python", "Prepare environment", "Start app"]:
            lab = tk.Label(steps, text=f"○ {text}", fg=self.palette["soft"], bg=self.palette["surface"], font=("Segoe UI", 9), anchor="w")
            lab.pack(side="left", padx=(0, 18))
            self.step_labels.append(lab)

        button_row = tk.Frame(outer, bg=self.palette["bg"])
        button_row.pack(fill="x")
        self.open_btn = self._button(button_row, "Open Pathmark", lambda: webbrowser.open(self.current_url()), primary=True, disabled=True)
        self.open_btn.pack(side="left")
        self.stop_btn = self._button(button_row, "Stop", self.stop_app, disabled=True)
        self.stop_btn.pack(side="left", padx=(10, 0))
        self.details_btn = self._button(button_row, "Show details", self.show_details)
        self.details_btn.pack(side="left", padx=(10, 0))
        self.update_btn = self._button(button_row, "Check for updates", self.check_for_updates)
        self.update_btn.pack(side="left", padx=(10, 0))

        self.footer = tk.Label(
            outer,
            text=f"{APP_VERSION}  •  Runs locally on this computer",
            font=("Segoe UI", 9),
            fg=self.palette["soft"],
            bg=self.palette["bg"],
            anchor="w",
        )
        self.footer.pack(fill="x", pady=(24, 0))

    def current_url(self) -> str:
        return f"http://localhost:{self.port}"

    def mark_step(self, index: int) -> None:
        for i, lab in enumerate(self.step_labels):
            if i < index:
                lab.config(text=lab.cget("text").replace("○", "●", 1), fg=self.palette["accent"])
            elif i == index:
                lab.config(text=lab.cget("text").replace("○", "●", 1), fg=self.palette["text"])

    def set_status(self, status: str, detail: str = "", value: int | None = None, step: int | None = None) -> None:
        self.status.config(text=status)
        self.detail.config(text=detail or status)
        if value is not None:
            self.progress["value"] = value
        if step is not None:
            self.mark_step(step)
        self.update_idletasks()

    def log(self, text: str) -> None:
        self.logs.append(text)
        self.log_queue.put(text)

    def drain_log(self) -> None:
        try:
            while True:
                self.log_queue.get_nowait()
        except queue.Empty:
            pass
        self.after(250, self.drain_log)

    def choose_python(self) -> list[str]:
        candidates = [["python3"], ["python"]]
        for cmd in candidates:
            try:
                subprocess.run(cmd + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
                return cmd
            except Exception:
                continue
        raise FileNotFoundError("Python 3 was not found.")

    def port_free(self, port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            return sock.connect_ex(("127.0.0.1", port)) != 0

    def choose_port(self) -> int:
        for port in range(DEFAULT_PORT, DEFAULT_PORT + 25):
            if self.port_free(port):
                return port
        return DEFAULT_PORT

    def run_and_log(self, args: list[str], label: str) -> None:
        self.log(f"$ {' '.join(args)}")
        proc = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        assert proc.stdout is not None
        for line in proc.stdout:
            self.log(line.rstrip())
        code = proc.wait()
        if code != 0:
            raise RuntimeError(f"{label} failed with exit code {code}")

    def start(self) -> None:
        if self.started:
            return
        self.started = True
        threading.Thread(target=self.worker, daemon=True).start()

    def worker(self) -> None:
        try:
            self.set_status("Checking app files", "Looking for the Pathmark app files.", 10, 0)
            if not APP_FILE.exists():
                raise FileNotFoundError(f"Missing app file: {APP_FILE}")
            if not REQUIREMENTS.exists():
                raise FileNotFoundError(f"Missing requirements file: {REQUIREMENTS}")

            self.set_status("Checking Python", "Pathmark uses Python to run the Pathmark app.", 24, 1)
            py_cmd = self.choose_python()

            self.set_status("Preparing local environment", "Creating a private app environment if needed.", 42, 2)
            if not VENV_PYTHON.exists():
                self.run_and_log(py_cmd + ["-m", "venv", str(VENV)], "Create environment")

            self.set_status("Installing app requirements", "This may take a minute the first time.", 62, 2)
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], "Upgrade pip")
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], "Install requirements")

            self.port = self.choose_port()
            self.set_status("Starting Pathmark", "Opening the Pathmark app in your browser.", 84, 3)
            self.proc = subprocess.Popen(
                [str(VENV_PYTHON), "-m", "streamlit", "run", str(APP_FILE), "--server.port", str(self.port)],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                creationflags=CREATE_NO_WINDOW,
            )
            self.after(1400, lambda: webbrowser.open(self.current_url()))
            self.after(0, lambda: (
                self.set_status("Pathmark is running", f"The app is open at {self.current_url()}", 100, 4),
                self.open_btn.config(state="normal"),
                self.stop_btn.config(state="normal"),
            ))
            assert self.proc.stdout is not None
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except FileNotFoundError as exc:
            self.log(str(exc))
            self.set_status("Python is needed", "Install Python 3.11 or later, then open Pathmark again.", 100)
            messagebox.showerror("Python is needed", "Python 3 was not found. Please install Python 3.11 or later, then open Pathmark again.")
            webbrowser.open("https://www.python.org/downloads/macos/")
        except Exception as exc:
            self.log(str(exc))
            self.set_status("Pathmark could not start", str(exc), 100)
            messagebox.showerror("Pathmark could not start", str(exc))

    def show_details(self) -> None:
        win = tk.Toplevel(self)
        win.title("Pathmark details")
        win.geometry("820x480")
        text = ScrolledText(win, wrap="word")
        text.pack(fill="both", expand=True)
        text.insert("1.0", "\n".join(self.logs))
        text.config(state="disabled")

    def check_for_updates(self) -> None:
        webbrowser.open(RELEASE_HUB_URL)

    def stop_app(self) -> None:
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                pass
        self.destroy()

    def on_close(self) -> None:
        self.stop_app()


if __name__ == "__main__":
    Launcher().mainloop()
