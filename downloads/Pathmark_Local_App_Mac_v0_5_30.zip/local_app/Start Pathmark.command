#!/bin/zsh
set -e
cd "$(dirname "$0")"
APP_PORT="${PATHMARK_PORT:-8545}"
echo "Starting Pathmark..."
echo "This window can remain open while Pathmark is running."
echo ""
if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display dialog "Python 3 is not installed. Please install Python 3 from python.org, then run Start Pathmark again." buttons {"Open Python download", "Cancel"} default button 1' >/dev/null 2>&1 || true
  open "https://www.python.org/downloads/macos/"
  exit 1
fi
if [ ! -d ".venv" ]; then
  echo "Creating local app environment..."
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install --upgrade pip >/dev/null
python -m pip install -r requirements.txt
echo ""
echo "Opening Pathmark in your browser..."
python -m streamlit run app/main.py --server.port "$APP_PORT"
