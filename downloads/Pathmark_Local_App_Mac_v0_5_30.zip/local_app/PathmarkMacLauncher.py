from __future__ import annotations
import os
import queue
import subprocess
import sys
import threading
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk
from tkinter.scrolledtext import ScrolledText

APP_NAME = "Pathmark"
APP_VERSION = "Local App v0.5.28"
DEFAULT_PORT = 8545
PYTHON_DOWNLOAD = "https://www.python.org/downloads/macos/"


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

ROOT = app_root()
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "bin" / "python"

class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("620x390")
        self.configure(bg="#241D17")
        self.proc = None
        self.q: queue.Queue[str] = queue.Queue()
        self.logs: list[str] = []
        self.port = DEFAULT_PORT
        self.palette = {
            "bg": "#241D17", "surface": "#30261E", "surface2": "#3A2F25",
            "text": "#F5EDE2", "muted": "#D8C7B3", "accent": "#B9855A",
            "accent2": "#D0A06F", "border": "#5A4939"
        }
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.build_ui()
        self.after(200, self.drain)
        self.after(600, self.start)

    def build_ui(self):
        style = ttk.Style(self)
        try: style.theme_use("clam")
        except Exception: pass
        style.configure("DS.Horizontal.TProgressbar", troughcolor=self.palette["surface"], background=self.palette["accent"])
        outer = tk.Frame(self, bg=self.palette["bg"]); outer.pack(fill="both", expand=True, padx=26, pady=22)
        tk.Label(outer, text="Pathmark", font=("Helvetica", 22, "bold"), fg=self.palette["text"], bg=self.palette["bg"], anchor="w").pack(fill="x")
        tk.Label(outer, text="Starting the local app. This may take a minute the first time.", font=("Helvetica", 11), fg=self.palette["muted"], bg=self.palette["bg"], anchor="w").pack(fill="x", pady=(4,18))
        card = tk.Frame(outer, bg=self.palette["surface"], highlightbackground=self.palette["border"], highlightthickness=1); card.pack(fill="x", pady=(0,16))
        self.status = tk.Label(card, text="Preparing launcher...", font=("Helvetica", 13, "bold"), fg=self.palette["text"], bg=self.palette["surface"], anchor="w"); self.status.pack(fill="x", padx=18, pady=(16,6))
        self.detail = tk.Label(card, text="Checking the app files.", font=("Helvetica", 11), fg=self.palette["muted"], bg=self.palette["surface"], anchor="w", wraplength=530, justify="left"); self.detail.pack(fill="x", padx=18, pady=(0,12))
        self.progress = ttk.Progressbar(card, style="DS.Horizontal.TProgressbar", mode="determinate", maximum=100); self.progress.pack(fill="x", padx=18, pady=(0,18)); self.progress["value"] = 5
        row = tk.Frame(outer, bg=self.palette["bg"]); row.pack(fill="x")
        self.open_btn = tk.Button(row, text="Open app", command=lambda: webbrowser.open(self.url()), state="disabled", bg=self.palette["accent"], fg="#1E1813", relief="flat", padx=16, pady=8); self.open_btn.pack(side="left")
        self.stop_btn = tk.Button(row, text="Stop app", command=self.stop, state="disabled", bg=self.palette["surface2"], fg=self.palette["text"], relief="flat", padx=16, pady=8); self.stop_btn.pack(side="left", padx=(10,0))
        tk.Button(row, text="Show details", command=self.show_details, bg=self.palette["surface2"], fg=self.palette["text"], relief="flat", padx=16, pady=8).pack(side="left", padx=(10,0))
        tk.Label(outer, text=f"{APP_VERSION} • Local files stay on this computer", font=("Helvetica", 10), fg="#BFAE9A", bg=self.palette["bg"], anchor="w").pack(fill="x", pady=(18,0))

    def url(self): return f"http://localhost:{self.port}"
    def set_status(self, status, detail="", value=None):
        self.status.config(text=status); self.detail.config(text=detail or status)
        if value is not None: self.progress["value"] = value
        self.update_idletasks()
    def log(self, text): self.logs.append(text); self.q.put(text)
    def run(self, args, label):
        self.log(f"$ {' '.join(map(str,args))}")
        p = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in p.stdout or []: self.log(line.rstrip())
        code = p.wait()
        if code != 0: raise RuntimeError(f"{label} failed with exit code {code}")
    def start(self): threading.Thread(target=self.worker, daemon=True).start()
    def worker(self):
        try:
            self.set_status("Checking app files", "Looking for the Pathmark app files.", 10)
            if not APP_FILE.exists(): raise FileNotFoundError(f"Missing {APP_FILE}")
            if not REQUIREMENTS.exists(): raise FileNotFoundError(f"Missing {REQUIREMENTS}")
            self.set_status("Checking Python", "Using Python 3 to start Pathmark.", 22)
            py = subprocess.check_output(["/usr/bin/env", "python3", "-c", "import sys; print(sys.executable)"], text=True).strip()
            self.set_status("Creating local environment", "Preparing Pathmark's private Python environment.", 38)
            if not VENV_PYTHON.exists(): self.run([py, "-m", "venv", str(VENV)], "Create environment")
            self.set_status("Installing requirements", "Installing or checking Pathmark's packages.", 58)
            self.run([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], "Upgrade pip")
            self.run([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], "Install requirements")
            self.set_status("Starting Pathmark", "Opening the local app in your browser.", 82)
            self.proc = subprocess.Popen([str(VENV_PYTHON), "-m", "streamlit", "run", str(APP_FILE), "--server.port", str(self.port)], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            self.after(1200, lambda: webbrowser.open(self.url()))
            self.after(0, lambda: (self.set_status("Pathmark is running", f"The app is available at {self.url()}", 100), self.open_btn.config(state="normal"), self.stop_btn.config(state="normal")))
            for line in self.proc.stdout or []: self.log(line.rstrip())
        except FileNotFoundError:
            messagebox.showerror("Python not found", "Python 3 was not found. Please install Python 3, then run Pathmark again.")
            webbrowser.open(PYTHON_DOWNLOAD)
        except Exception as e:
            self.log(str(e)); self.set_status("Pathmark could not start", str(e), 100); messagebox.showerror("Pathmark could not start", str(e))
    def drain(self):
        try:
            while True: self.q.get_nowait()
        except queue.Empty: pass
        self.after(250, self.drain)
    def show_details(self):
        win = tk.Toplevel(self); win.title("Pathmark details"); win.geometry("760x420")
        text = ScrolledText(win, wrap="word"); text.pack(fill="both", expand=True)
        text.insert("1.0", "\n".join(self.logs)); text.config(state="disabled")
    def stop(self):
        if self.proc and self.proc.poll() is None: self.proc.terminate()
        self.destroy()
    def on_close(self): self.stop()

if __name__ == "__main__":
    Launcher().mainloop()
