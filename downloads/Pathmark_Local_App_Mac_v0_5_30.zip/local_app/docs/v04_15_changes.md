# v0.4.15 changes

- Reworked routine repeat controls to use clearer Google Calendar-style grammar.
- Added monthly repeat options for day-of-month and ordinal weekday patterns.
- Improved ICS RRULE conversion for the new repeat text.
- Changed Calendar location labels to Location.
