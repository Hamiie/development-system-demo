# v0.5.14 changes

- Restored Google Tasks export to comma-delimited CSV with a `.csv` extension.
- Google Tasks exports now write to the configured `GoogleTasksExports` folder.
- Kept the required Apps Script-compatible columns first: Task ID, Task List, Title, Notes, Due Date, Reminder Time, Status.
- Extra columns remain after those required columns for repeat pattern and linked Google Calendar item.
- User-facing dates remain NZ-style; export due dates remain machine-readable.
