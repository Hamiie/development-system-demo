# v0.4.13 changes

This revision focuses on making Google Calendar and Google Tasks export settings more concrete and consistent.

- Goal actions now include a Starting prompt, calendar start/end time, calendar location, and Google Tasks prompt time.
- Routines use the same Google Calendar / Google Tasks language as goal actions.
- Google Tasks rows now use the Starting prompt where available, rather than simply duplicating the action title.
- Help icons use Streamlit defaults again.
- Removed implementation-facing text from the Areas page.
