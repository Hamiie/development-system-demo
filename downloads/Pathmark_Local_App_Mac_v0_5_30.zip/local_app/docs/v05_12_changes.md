# v0.5.12 changes

- Routine activities now have their own activity day(s), while inheriting the parent routine repeat interval.
- Routine activity status remains Included / Paused, rather than Done.
- Existing imported routine activities can infer activity days from old scheduled dates or weekday text in their notes.
- Routine statuses now include Captured, Active, and Retired.
- Fixed the `reminder_note()` argument error when editing goal actions.
- Google Calendar export uses one recurring event per routine activity, with activity-specific days/times.
- Google Tasks export produces repeated prompt rows for routine activity occurrences and keeps the Apps Script-compatible leading columns.
