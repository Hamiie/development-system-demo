# v0.4.14 changes

This build revises the Google Calendar / Google Tasks model.

## Google Calendar and Google Tasks

- Google Calendar is treated as the protected time block.
- Google Tasks is treated as the starting cue that reduces friction to begin.
- The Starting prompt now appears inside the Google Calendar and Google Tasks block.
- Google Tasks exports now use the starting prompt as the task title.
- If a Google Tasks prompt is linked to a Google Calendar time block, the task notes include the related calendar item name, time, and calendar.
- The link note is designed so that if one item changes, the user knows which related item to update.

## Repeats

- Routine repeat settings continue to use Google-style repeat controls.
- The repeat pattern is converted to an ICS RRULE for Google Calendar exports where possible.
- Monthly ordinal weekday patterns such as first Monday of every month are supported.

## Export tables

- Google Tasks Export now shows the related Google Calendar item rather than only a Yes/No link.
- Google Calendar Export now shows the repeat rule column.
