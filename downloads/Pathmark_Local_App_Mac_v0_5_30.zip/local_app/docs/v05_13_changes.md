# v0.5.14

- Google Tasks prompts now use the scheduled date first.
- Google Calendar export now preserves user-entered duration more robustly, including afternoon shorthand such as 12:00 to 3:00.
- Google Tasks exports are now comma-delimited .csv files while preserving the Apps Script-compatible columns.
