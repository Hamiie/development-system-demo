from pathlib import Path
import os
import tkinter as tk
from tkinter import ttk, messagebox

ROOT = Path(__file__).resolve().parents[1]
GUIDE = ROOT / "docs" / "Google Tasks Import Setup.md"
SCRIPT = ROOT / "docs" / "import_pathmark_tasks_to_google_tasks.gs"

class Helper(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Pathmark Google Tasks setup")
        self.geometry("620x420")
        self.minsize(560, 360)
        self.configure(bg="#F7F3EC")
        frame = ttk.Frame(self, padding=18)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Set up Google Tasks import", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Pathmark exports Google Tasks prompts as CSV files. This helper opens the guide and script you need to create the Google Sheet importer.", wraplength=560).pack(anchor="w", pady=(8, 16))
        steps = [
            "1. Open or create a Google Sheet called Pathmark Task Import.",
            "2. Open Extensions > Apps Script.",
            "3. Copy the Apps Script file into the editor.",
            "4. Enable the Tasks API service in Apps Script.",
            "5. Run importPathmarkTasksToGoogleTasks.",
        ]
        for step in steps:
            ttk.Label(frame, text=step, wraplength=560).pack(anchor="w", pady=2)
        btns = ttk.Frame(frame)
        btns.pack(anchor="w", pady=18)
        ttk.Button(btns, text="Open setup guide", command=lambda: self.open_path(GUIDE)).pack(side="left", padx=(0, 8))
        ttk.Button(btns, text="Open Apps Script file", command=lambda: self.open_path(SCRIPT)).pack(side="left", padx=(0, 8))
        ttk.Button(btns, text="Copy script to clipboard", command=self.copy_script).pack(side="left")
        ttk.Label(frame, text="This helper does not access your Google account. It only opens local setup files.", wraplength=560).pack(anchor="w", pady=(18, 0))
    def open_path(self, path: Path):
        if not path.exists():
            messagebox.showerror("Missing file", f"Could not find:\n{path}")
            return
        os.startfile(str(path))
    def copy_script(self):
        if not SCRIPT.exists():
            messagebox.showerror("Missing file", f"Could not find:\n{SCRIPT}")
            return
        self.clipboard_clear()
        self.clipboard_append(SCRIPT.read_text(encoding="utf-8"))
        messagebox.showinfo("Copied", "The Apps Script code has been copied to the clipboard.")

if __name__ == "__main__":
    Helper().mainloop()
