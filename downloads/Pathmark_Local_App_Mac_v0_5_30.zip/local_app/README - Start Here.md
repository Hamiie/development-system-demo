# Start Pathmark on Mac

Pathmark runs locally on your Mac and opens in your browser. This lets it create your Pathmark folder, tasklists, backups, Google Calendar exports, and Google Tasks exports on your own computer.

## Start the app

1. Extract the zip file.
2. Open the `local_app` folder.
3. Double-click `Start Pathmark.command`.
4. If macOS asks for permission, choose to open it.
5. Pathmark will open in your browser.

The first launch can take a few minutes while Pathmark creates its private Python environment and installs the required packages.

## If macOS blocks the launcher

Control-click `Start Pathmark.command`, choose **Open**, then confirm.

## Optional app-style launcher

If you want to build a small Mac app launcher, run:

`Build Pathmark Launcher App.command`

This creates `dist/Start Pathmark.app`. Building this app requires Python 3 and may still show macOS security warnings because the app is not code-signed.

## Safety

Pathmark should create missing folders and files only. It should not delete your files or replace your Pathmark folder during updates.
