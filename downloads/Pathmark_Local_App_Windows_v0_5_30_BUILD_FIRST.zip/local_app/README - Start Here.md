# Start Pathmark on Windows

Pathmark runs locally on your computer and opens in your browser.

## First run

1. Extract this zip file.
2. Open the extracted `local_app` folder.
3. Run `build_launcher_exe.bat` once.
4. This creates `Pathmark.exe`.
5. Open `Pathmark.exe` to start the app.

If the executable cannot be built, use `Start Pathmark.cmd` as the fallback launcher.

## Where your files go

Pathmark will ask where to keep your Pathmark folder on first setup. Your tasklists, backups, Google Calendar exports, Google Tasks exports, and database are kept in that folder, outside the replaceable app files.
