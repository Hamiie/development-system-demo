@echo off
setlocal
cd /d "%~dp0"
title Pathmark

if exist "Pathmark.exe" (
  "Pathmark.exe"
  exit /b %ERRORLEVEL%
)

echo Pathmark
echo.
echo The friendly launcher executable was not found, so this fallback will start the launcher with Python.
echo.

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py DevelopmentSystemLauncher.py
  exit /b %ERRORLEVEL%
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python DevelopmentSystemLauncher.py
  exit /b %ERRORLEVEL%
)

echo Python was not found on this computer.
echo Please install Python 3.11 or later from https://www.python.org/downloads/
echo Then run this file again.
pause
