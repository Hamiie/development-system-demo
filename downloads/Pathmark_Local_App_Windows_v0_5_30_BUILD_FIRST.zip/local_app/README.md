# Pathmark Local App Package for Windows

This package contains the local Pathmark app.

## First step: build the launcher

Before starting Pathmark for the first time, run:

```text
build_launcher_exe.bat
```

This creates:

```text
Pathmark.exe
```

After that, open:

```text
Pathmark.exe
```

The fallback launcher is:

```text
Pathmark.cmd
```

Use the fallback only if the executable cannot be built or does not start.

## What Pathmark does

Pathmark opens locally in your browser and asks where it should keep your system. The recommended folder for a new setup is:

```text
Documents\Pathmark
```

Pathmark creates missing folders and files only. It does not delete your existing files. Planning files are backed up before they are updated.

## Updating safely

The app folder is replaceable. Your Pathmark folder is not.

Before updating, open Pathmark and create an update backup. Then replace only the `local_app` folder.
