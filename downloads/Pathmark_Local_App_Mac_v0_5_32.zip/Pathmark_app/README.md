# Pathmark Mac app source

This folder contains the local Mac version of Pathmark.

Move the full `Pathmark_app` folder into the user's Pathmark folder, for example:

```text
~/Documents/Pathmark/Pathmark_app
```

Open `Start Pathmark.command` to run Pathmark locally.
