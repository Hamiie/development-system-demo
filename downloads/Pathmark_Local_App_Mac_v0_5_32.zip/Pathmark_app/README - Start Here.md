# Start Pathmark on Mac

Pathmark runs on your computer and opens in your browser.

## First setup

1. Extract the zip file.
2. Move the extracted `Pathmark_app` folder to the folder where you want to keep Pathmark.

   Recommended:

   ```text
   ~/Documents/Pathmark/Pathmark_app
   ```

3. Open `Pathmark_app`.
4. Open `Start Pathmark.command`.

Optional: run `Build Pathmark Launcher App.command` to create a more app-like launcher.

## Where your files go

On first launch, Pathmark will ask where to keep your Pathmark system. For most users, this should be the parent folder that contains `Pathmark_app`.

Pathmark keeps your tasklists, backups, Google Calendar exports, Google Tasks exports, database, and planning files outside the replaceable app folder.

Recommended structure:

```text
Pathmark
├── 00_System
│   ├── pathmark.db
│   ├── Backups
│   ├── Tasklists
│   ├── Google Calendar Exports
│   └── Google Tasks Exports
├── 01_Body_And_Stability
├── 02_Home_And_Garden
└── Pathmark_app
    ├── Start Pathmark.command
    ├── app
    ├── config
    └── requirements.txt
```

## Updating Pathmark

Before updating, open Pathmark and create an update backup.

Then replace only:

```text
Pathmark_app
```

Do not replace `00_System`, backups, tasklists, exports, or area folders.
